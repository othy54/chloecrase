-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES
(1,1,'A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2026-02-15 17:41:30','2026-02-15 17:41:30','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com/\">Gravatar</a>.',0,'1','','comment',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_litespeed_url`
--

DROP TABLE IF EXISTS `wp_litespeed_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_litespeed_url` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(500) NOT NULL,
  `cache_tags` varchar(1000) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`(191)),
  KEY `cache_tags` (`cache_tags`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_litespeed_url`
--

LOCK TABLES `wp_litespeed_url` WRITE;
/*!40000 ALTER TABLE `wp_litespeed_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_litespeed_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_litespeed_url_file`
--

DROP TABLE IF EXISTS `wp_litespeed_url_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_litespeed_url_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url_id` bigint(20) NOT NULL,
  `vary` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5 of final vary',
  `filename` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5 of file content',
  `type` tinyint(4) NOT NULL COMMENT 'css=1,js=2,ccss=3,ucss=4',
  `mobile` tinyint(4) NOT NULL COMMENT 'mobile=1',
  `webp` tinyint(4) NOT NULL COMMENT 'webp=1',
  `expired` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`),
  KEY `type` (`type`),
  KEY `url_id_2` (`url_id`,`vary`,`type`),
  KEY `filename_2` (`filename`,`expired`),
  KEY `url_id` (`url_id`,`expired`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_litespeed_url_file`
--

LOCK TABLES `wp_litespeed_url_file` WRITE;
/*!40000 ALTER TABLE `wp_litespeed_url_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_litespeed_url_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=863 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES
(1,'cron','a:13:{i:1772139640;a:1:{s:19:\"litespeed_task_lqip\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:16:\"litespeed_filter\";s:4:\"args\";a:0:{}s:8:\"interval\";i:900;}}}i:1772142108;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1772170898;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1772174490;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1772176290;a:1:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1772178090;a:1:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1772214097;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1772214098;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1772214101;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1772386958;a:1:{s:30:\"wp_delete_temp_updater_backups\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1772394704;a:1:{s:27:\"acf_update_site_health_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1772473297;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}','on'),
(2,'siteurl','https://chloecrase.ddev.site/wp','on'),
(3,'home','https://chloecrase.ddev.site/wp','on'),
(4,'blogname','Chloe Crase','on'),
(5,'blogdescription','','on'),
(6,'users_can_register','0','on'),
(7,'admin_email','othman.bensaoula@gmail.com','on'),
(8,'start_of_week','1','on'),
(9,'use_balanceTags','0','on'),
(10,'use_smilies','1','on'),
(11,'require_name_email','1','on'),
(12,'comments_notify','1','on'),
(13,'posts_per_rss','10','on'),
(14,'rss_use_excerpt','0','on'),
(15,'mailserver_url','mail.example.com','on'),
(16,'mailserver_login','login@example.com','on'),
(17,'mailserver_pass','','on'),
(18,'mailserver_port','110','on'),
(19,'default_category','1','on'),
(20,'default_comment_status','open','on'),
(21,'default_ping_status','open','on'),
(22,'default_pingback_flag','0','on'),
(23,'posts_per_page','10','on'),
(24,'date_format','F j, Y','on'),
(25,'time_format','g:i a','on'),
(26,'links_updated_date_format','F j, Y g:i a','on'),
(27,'comment_moderation','0','on'),
(28,'moderation_notify','1','on'),
(29,'permalink_structure','/%postname%/','on'),
(30,'rewrite_rules','a:118:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:9:\"projet/?$\";s:27:\"index.php?post_type=project\";s:39:\"projet/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=project&feed=$matches[1]\";s:34:\"projet/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=project&feed=$matches[1]\";s:26:\"projet/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=project&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:34:\"projet/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"projet/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"projet/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"projet/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"projet/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"projet/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:23:\"projet/([^/]+)/embed/?$\";s:40:\"index.php?project=$matches[1]&embed=true\";s:27:\"projet/([^/]+)/trackback/?$\";s:34:\"index.php?project=$matches[1]&tb=1\";s:47:\"projet/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?project=$matches[1]&feed=$matches[2]\";s:42:\"projet/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?project=$matches[1]&feed=$matches[2]\";s:35:\"projet/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?project=$matches[1]&paged=$matches[2]\";s:42:\"projet/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?project=$matches[1]&cpage=$matches[2]\";s:31:\"projet/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?project=$matches[1]&page=$matches[2]\";s:23:\"projet/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:33:\"projet/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:53:\"projet/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"projet/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"projet/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:29:\"projet/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:12:\"sitemap\\.xml\";s:23:\"index.php?sitemap=index\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=5&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','on'),
(31,'hack_file','0','on'),
(32,'blog_charset','UTF-8','on'),
(33,'moderation_keys','','off'),
(34,'active_plugins','a:2:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:35:\"litespeed-cache/litespeed-cache.php\";}','on'),
(35,'category_base','','on'),
(36,'ping_sites','https://rpc.pingomatic.com/','on'),
(37,'comment_max_links','2','on'),
(38,'gmt_offset','0','on'),
(39,'default_email_category','1','on'),
(40,'recently_edited','','off'),
(41,'template','sage','on'),
(42,'stylesheet','sage','on'),
(43,'comment_registration','0','on'),
(44,'html_type','text/html','on'),
(45,'use_trackback','0','on'),
(46,'default_role','subscriber','on'),
(47,'db_version','60717','on'),
(48,'uploads_use_yearmonth_folders','1','on'),
(49,'upload_path','','on'),
(50,'blog_public','0','on'),
(51,'default_link_category','2','on'),
(52,'show_on_front','page','on'),
(53,'tag_base','','on'),
(54,'show_avatars','1','on'),
(55,'avatar_rating','G','on'),
(56,'upload_url_path','','on'),
(57,'thumbnail_size_w','150','on'),
(58,'thumbnail_size_h','150','on'),
(59,'thumbnail_crop','1','on'),
(60,'medium_size_w','300','on'),
(61,'medium_size_h','300','on'),
(62,'avatar_default','mystery','on'),
(63,'large_size_w','1024','on'),
(64,'large_size_h','1024','on'),
(65,'image_default_link_type','none','on'),
(66,'image_default_size','','on'),
(67,'image_default_align','','on'),
(68,'close_comments_for_old_posts','0','on'),
(69,'close_comments_days_old','14','on'),
(70,'thread_comments','1','on'),
(71,'thread_comments_depth','5','on'),
(72,'page_comments','0','on'),
(73,'comments_per_page','50','on'),
(74,'default_comments_page','newest','on'),
(75,'comment_order','asc','on'),
(76,'sticky_posts','a:0:{}','on'),
(77,'widget_categories','a:0:{}','on'),
(78,'widget_text','a:0:{}','on'),
(79,'widget_rss','a:0:{}','on'),
(80,'uninstall_plugins','a:1:{s:35:\"litespeed-cache/litespeed-cache.php\";s:47:\"LiteSpeed\\Activation::uninstall_litespeed_cache\";}','off'),
(81,'timezone_string','','on'),
(82,'page_for_posts','0','on'),
(83,'page_on_front','5','on'),
(84,'default_post_format','0','on'),
(85,'link_manager_enabled','0','on'),
(86,'finished_splitting_shared_terms','1','on'),
(87,'site_icon','0','on'),
(88,'medium_large_size_w','768','on'),
(89,'medium_large_size_h','0','on'),
(90,'wp_page_for_privacy_policy','3','on'),
(91,'show_comments_cookies_opt_in','1','on'),
(92,'admin_email_lifespan','1786729290','on'),
(93,'disallowed_keys','','off'),
(94,'comment_previously_approved','1','on'),
(95,'auto_plugin_theme_update_emails','a:0:{}','off'),
(96,'auto_update_core_dev','enabled','on'),
(97,'auto_update_core_minor','enabled','on'),
(98,'auto_update_core_major','enabled','on'),
(99,'wp_force_deactivated_plugins','a:0:{}','on'),
(100,'wp_attachment_pages_enabled','0','on'),
(101,'wp_notes_notify','1','on'),
(102,'initial_db_version','60717','on'),
(103,'wp_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','on'),
(104,'fresh_site','0','off'),
(105,'user_count','1','off'),
(106,'widget_block','a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}','auto'),
(107,'sidebars_widgets','a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"sidebar-primary\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:14:\"sidebar-footer\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:13:\"array_version\";i:3;}','auto'),
(108,'bedrock_autoloader','a:2:{s:7:\"plugins\";a:1:{s:55:\"bedrock-disallow-indexing/bedrock-disallow-indexing.php\";a:15:{s:4:\"Name\";s:17:\"Disallow Indexing\";s:9:\"PluginURI\";s:25:\"https://roots.io/bedrock/\";s:7:\"Version\";s:5:\"2.0.0\";s:11:\"Description\";s:62:\"Disallow indexing of your site on non-production environments.\";s:6:\"Author\";s:5:\"Roots\";s:9:\"AuthorURI\";s:17:\"https://roots.io/\";s:10:\"TextDomain\";s:5:\"roots\";s:10:\"DomainPath\";s:0:\"\";s:7:\"Network\";b:0;s:10:\"RequiresWP\";s:0:\"\";s:11:\"RequiresPHP\";s:0:\"\";s:9:\"UpdateURI\";s:0:\"\";s:15:\"RequiresPlugins\";s:0:\"\";s:5:\"Title\";s:17:\"Disallow Indexing\";s:10:\"AuthorName\";s:5:\"Roots\";}}s:5:\"count\";i:1;}','off'),
(109,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(110,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(111,'widget_archives','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(112,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(113,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(114,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(115,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(116,'widget_meta','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(117,'widget_search','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(118,'widget_recent-posts','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(119,'widget_recent-comments','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(120,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(121,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(122,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(123,'_transient_wp_core_block_css_files','a:2:{s:7:\"version\";s:5:\"6.9.1\";s:5:\"files\";a:584:{i:0;s:31:\"accordion-heading/style-rtl.css\";i:1;s:35:\"accordion-heading/style-rtl.min.css\";i:2;s:27:\"accordion-heading/style.css\";i:3;s:31:\"accordion-heading/style.min.css\";i:4;s:28:\"accordion-item/style-rtl.css\";i:5;s:32:\"accordion-item/style-rtl.min.css\";i:6;s:24:\"accordion-item/style.css\";i:7;s:28:\"accordion-item/style.min.css\";i:8;s:29:\"accordion-panel/style-rtl.css\";i:9;s:33:\"accordion-panel/style-rtl.min.css\";i:10;s:25:\"accordion-panel/style.css\";i:11;s:29:\"accordion-panel/style.min.css\";i:12;s:23:\"accordion/style-rtl.css\";i:13;s:27:\"accordion/style-rtl.min.css\";i:14;s:19:\"accordion/style.css\";i:15;s:23:\"accordion/style.min.css\";i:16;s:23:\"archives/editor-rtl.css\";i:17;s:27:\"archives/editor-rtl.min.css\";i:18;s:19:\"archives/editor.css\";i:19;s:23:\"archives/editor.min.css\";i:20;s:22:\"archives/style-rtl.css\";i:21;s:26:\"archives/style-rtl.min.css\";i:22;s:18:\"archives/style.css\";i:23;s:22:\"archives/style.min.css\";i:24;s:20:\"audio/editor-rtl.css\";i:25;s:24:\"audio/editor-rtl.min.css\";i:26;s:16:\"audio/editor.css\";i:27;s:20:\"audio/editor.min.css\";i:28;s:19:\"audio/style-rtl.css\";i:29;s:23:\"audio/style-rtl.min.css\";i:30;s:15:\"audio/style.css\";i:31;s:19:\"audio/style.min.css\";i:32;s:19:\"audio/theme-rtl.css\";i:33;s:23:\"audio/theme-rtl.min.css\";i:34;s:15:\"audio/theme.css\";i:35;s:19:\"audio/theme.min.css\";i:36;s:21:\"avatar/editor-rtl.css\";i:37;s:25:\"avatar/editor-rtl.min.css\";i:38;s:17:\"avatar/editor.css\";i:39;s:21:\"avatar/editor.min.css\";i:40;s:20:\"avatar/style-rtl.css\";i:41;s:24:\"avatar/style-rtl.min.css\";i:42;s:16:\"avatar/style.css\";i:43;s:20:\"avatar/style.min.css\";i:44;s:21:\"button/editor-rtl.css\";i:45;s:25:\"button/editor-rtl.min.css\";i:46;s:17:\"button/editor.css\";i:47;s:21:\"button/editor.min.css\";i:48;s:20:\"button/style-rtl.css\";i:49;s:24:\"button/style-rtl.min.css\";i:50;s:16:\"button/style.css\";i:51;s:20:\"button/style.min.css\";i:52;s:22:\"buttons/editor-rtl.css\";i:53;s:26:\"buttons/editor-rtl.min.css\";i:54;s:18:\"buttons/editor.css\";i:55;s:22:\"buttons/editor.min.css\";i:56;s:21:\"buttons/style-rtl.css\";i:57;s:25:\"buttons/style-rtl.min.css\";i:58;s:17:\"buttons/style.css\";i:59;s:21:\"buttons/style.min.css\";i:60;s:22:\"calendar/style-rtl.css\";i:61;s:26:\"calendar/style-rtl.min.css\";i:62;s:18:\"calendar/style.css\";i:63;s:22:\"calendar/style.min.css\";i:64;s:25:\"categories/editor-rtl.css\";i:65;s:29:\"categories/editor-rtl.min.css\";i:66;s:21:\"categories/editor.css\";i:67;s:25:\"categories/editor.min.css\";i:68;s:24:\"categories/style-rtl.css\";i:69;s:28:\"categories/style-rtl.min.css\";i:70;s:20:\"categories/style.css\";i:71;s:24:\"categories/style.min.css\";i:72;s:19:\"code/editor-rtl.css\";i:73;s:23:\"code/editor-rtl.min.css\";i:74;s:15:\"code/editor.css\";i:75;s:19:\"code/editor.min.css\";i:76;s:18:\"code/style-rtl.css\";i:77;s:22:\"code/style-rtl.min.css\";i:78;s:14:\"code/style.css\";i:79;s:18:\"code/style.min.css\";i:80;s:18:\"code/theme-rtl.css\";i:81;s:22:\"code/theme-rtl.min.css\";i:82;s:14:\"code/theme.css\";i:83;s:18:\"code/theme.min.css\";i:84;s:22:\"columns/editor-rtl.css\";i:85;s:26:\"columns/editor-rtl.min.css\";i:86;s:18:\"columns/editor.css\";i:87;s:22:\"columns/editor.min.css\";i:88;s:21:\"columns/style-rtl.css\";i:89;s:25:\"columns/style-rtl.min.css\";i:90;s:17:\"columns/style.css\";i:91;s:21:\"columns/style.min.css\";i:92;s:33:\"comment-author-name/style-rtl.css\";i:93;s:37:\"comment-author-name/style-rtl.min.css\";i:94;s:29:\"comment-author-name/style.css\";i:95;s:33:\"comment-author-name/style.min.css\";i:96;s:29:\"comment-content/style-rtl.css\";i:97;s:33:\"comment-content/style-rtl.min.css\";i:98;s:25:\"comment-content/style.css\";i:99;s:29:\"comment-content/style.min.css\";i:100;s:26:\"comment-date/style-rtl.css\";i:101;s:30:\"comment-date/style-rtl.min.css\";i:102;s:22:\"comment-date/style.css\";i:103;s:26:\"comment-date/style.min.css\";i:104;s:31:\"comment-edit-link/style-rtl.css\";i:105;s:35:\"comment-edit-link/style-rtl.min.css\";i:106;s:27:\"comment-edit-link/style.css\";i:107;s:31:\"comment-edit-link/style.min.css\";i:108;s:32:\"comment-reply-link/style-rtl.css\";i:109;s:36:\"comment-reply-link/style-rtl.min.css\";i:110;s:28:\"comment-reply-link/style.css\";i:111;s:32:\"comment-reply-link/style.min.css\";i:112;s:30:\"comment-template/style-rtl.css\";i:113;s:34:\"comment-template/style-rtl.min.css\";i:114;s:26:\"comment-template/style.css\";i:115;s:30:\"comment-template/style.min.css\";i:116;s:42:\"comments-pagination-numbers/editor-rtl.css\";i:117;s:46:\"comments-pagination-numbers/editor-rtl.min.css\";i:118;s:38:\"comments-pagination-numbers/editor.css\";i:119;s:42:\"comments-pagination-numbers/editor.min.css\";i:120;s:34:\"comments-pagination/editor-rtl.css\";i:121;s:38:\"comments-pagination/editor-rtl.min.css\";i:122;s:30:\"comments-pagination/editor.css\";i:123;s:34:\"comments-pagination/editor.min.css\";i:124;s:33:\"comments-pagination/style-rtl.css\";i:125;s:37:\"comments-pagination/style-rtl.min.css\";i:126;s:29:\"comments-pagination/style.css\";i:127;s:33:\"comments-pagination/style.min.css\";i:128;s:29:\"comments-title/editor-rtl.css\";i:129;s:33:\"comments-title/editor-rtl.min.css\";i:130;s:25:\"comments-title/editor.css\";i:131;s:29:\"comments-title/editor.min.css\";i:132;s:23:\"comments/editor-rtl.css\";i:133;s:27:\"comments/editor-rtl.min.css\";i:134;s:19:\"comments/editor.css\";i:135;s:23:\"comments/editor.min.css\";i:136;s:22:\"comments/style-rtl.css\";i:137;s:26:\"comments/style-rtl.min.css\";i:138;s:18:\"comments/style.css\";i:139;s:22:\"comments/style.min.css\";i:140;s:20:\"cover/editor-rtl.css\";i:141;s:24:\"cover/editor-rtl.min.css\";i:142;s:16:\"cover/editor.css\";i:143;s:20:\"cover/editor.min.css\";i:144;s:19:\"cover/style-rtl.css\";i:145;s:23:\"cover/style-rtl.min.css\";i:146;s:15:\"cover/style.css\";i:147;s:19:\"cover/style.min.css\";i:148;s:22:\"details/editor-rtl.css\";i:149;s:26:\"details/editor-rtl.min.css\";i:150;s:18:\"details/editor.css\";i:151;s:22:\"details/editor.min.css\";i:152;s:21:\"details/style-rtl.css\";i:153;s:25:\"details/style-rtl.min.css\";i:154;s:17:\"details/style.css\";i:155;s:21:\"details/style.min.css\";i:156;s:20:\"embed/editor-rtl.css\";i:157;s:24:\"embed/editor-rtl.min.css\";i:158;s:16:\"embed/editor.css\";i:159;s:20:\"embed/editor.min.css\";i:160;s:19:\"embed/style-rtl.css\";i:161;s:23:\"embed/style-rtl.min.css\";i:162;s:15:\"embed/style.css\";i:163;s:19:\"embed/style.min.css\";i:164;s:19:\"embed/theme-rtl.css\";i:165;s:23:\"embed/theme-rtl.min.css\";i:166;s:15:\"embed/theme.css\";i:167;s:19:\"embed/theme.min.css\";i:168;s:19:\"file/editor-rtl.css\";i:169;s:23:\"file/editor-rtl.min.css\";i:170;s:15:\"file/editor.css\";i:171;s:19:\"file/editor.min.css\";i:172;s:18:\"file/style-rtl.css\";i:173;s:22:\"file/style-rtl.min.css\";i:174;s:14:\"file/style.css\";i:175;s:18:\"file/style.min.css\";i:176;s:23:\"footnotes/style-rtl.css\";i:177;s:27:\"footnotes/style-rtl.min.css\";i:178;s:19:\"footnotes/style.css\";i:179;s:23:\"footnotes/style.min.css\";i:180;s:23:\"freeform/editor-rtl.css\";i:181;s:27:\"freeform/editor-rtl.min.css\";i:182;s:19:\"freeform/editor.css\";i:183;s:23:\"freeform/editor.min.css\";i:184;s:22:\"gallery/editor-rtl.css\";i:185;s:26:\"gallery/editor-rtl.min.css\";i:186;s:18:\"gallery/editor.css\";i:187;s:22:\"gallery/editor.min.css\";i:188;s:21:\"gallery/style-rtl.css\";i:189;s:25:\"gallery/style-rtl.min.css\";i:190;s:17:\"gallery/style.css\";i:191;s:21:\"gallery/style.min.css\";i:192;s:21:\"gallery/theme-rtl.css\";i:193;s:25:\"gallery/theme-rtl.min.css\";i:194;s:17:\"gallery/theme.css\";i:195;s:21:\"gallery/theme.min.css\";i:196;s:20:\"group/editor-rtl.css\";i:197;s:24:\"group/editor-rtl.min.css\";i:198;s:16:\"group/editor.css\";i:199;s:20:\"group/editor.min.css\";i:200;s:19:\"group/style-rtl.css\";i:201;s:23:\"group/style-rtl.min.css\";i:202;s:15:\"group/style.css\";i:203;s:19:\"group/style.min.css\";i:204;s:19:\"group/theme-rtl.css\";i:205;s:23:\"group/theme-rtl.min.css\";i:206;s:15:\"group/theme.css\";i:207;s:19:\"group/theme.min.css\";i:208;s:21:\"heading/style-rtl.css\";i:209;s:25:\"heading/style-rtl.min.css\";i:210;s:17:\"heading/style.css\";i:211;s:21:\"heading/style.min.css\";i:212;s:19:\"html/editor-rtl.css\";i:213;s:23:\"html/editor-rtl.min.css\";i:214;s:15:\"html/editor.css\";i:215;s:19:\"html/editor.min.css\";i:216;s:20:\"image/editor-rtl.css\";i:217;s:24:\"image/editor-rtl.min.css\";i:218;s:16:\"image/editor.css\";i:219;s:20:\"image/editor.min.css\";i:220;s:19:\"image/style-rtl.css\";i:221;s:23:\"image/style-rtl.min.css\";i:222;s:15:\"image/style.css\";i:223;s:19:\"image/style.min.css\";i:224;s:19:\"image/theme-rtl.css\";i:225;s:23:\"image/theme-rtl.min.css\";i:226;s:15:\"image/theme.css\";i:227;s:19:\"image/theme.min.css\";i:228;s:29:\"latest-comments/style-rtl.css\";i:229;s:33:\"latest-comments/style-rtl.min.css\";i:230;s:25:\"latest-comments/style.css\";i:231;s:29:\"latest-comments/style.min.css\";i:232;s:27:\"latest-posts/editor-rtl.css\";i:233;s:31:\"latest-posts/editor-rtl.min.css\";i:234;s:23:\"latest-posts/editor.css\";i:235;s:27:\"latest-posts/editor.min.css\";i:236;s:26:\"latest-posts/style-rtl.css\";i:237;s:30:\"latest-posts/style-rtl.min.css\";i:238;s:22:\"latest-posts/style.css\";i:239;s:26:\"latest-posts/style.min.css\";i:240;s:18:\"list/style-rtl.css\";i:241;s:22:\"list/style-rtl.min.css\";i:242;s:14:\"list/style.css\";i:243;s:18:\"list/style.min.css\";i:244;s:22:\"loginout/style-rtl.css\";i:245;s:26:\"loginout/style-rtl.min.css\";i:246;s:18:\"loginout/style.css\";i:247;s:22:\"loginout/style.min.css\";i:248;s:19:\"math/editor-rtl.css\";i:249;s:23:\"math/editor-rtl.min.css\";i:250;s:15:\"math/editor.css\";i:251;s:19:\"math/editor.min.css\";i:252;s:18:\"math/style-rtl.css\";i:253;s:22:\"math/style-rtl.min.css\";i:254;s:14:\"math/style.css\";i:255;s:18:\"math/style.min.css\";i:256;s:25:\"media-text/editor-rtl.css\";i:257;s:29:\"media-text/editor-rtl.min.css\";i:258;s:21:\"media-text/editor.css\";i:259;s:25:\"media-text/editor.min.css\";i:260;s:24:\"media-text/style-rtl.css\";i:261;s:28:\"media-text/style-rtl.min.css\";i:262;s:20:\"media-text/style.css\";i:263;s:24:\"media-text/style.min.css\";i:264;s:19:\"more/editor-rtl.css\";i:265;s:23:\"more/editor-rtl.min.css\";i:266;s:15:\"more/editor.css\";i:267;s:19:\"more/editor.min.css\";i:268;s:30:\"navigation-link/editor-rtl.css\";i:269;s:34:\"navigation-link/editor-rtl.min.css\";i:270;s:26:\"navigation-link/editor.css\";i:271;s:30:\"navigation-link/editor.min.css\";i:272;s:29:\"navigation-link/style-rtl.css\";i:273;s:33:\"navigation-link/style-rtl.min.css\";i:274;s:25:\"navigation-link/style.css\";i:275;s:29:\"navigation-link/style.min.css\";i:276;s:33:\"navigation-submenu/editor-rtl.css\";i:277;s:37:\"navigation-submenu/editor-rtl.min.css\";i:278;s:29:\"navigation-submenu/editor.css\";i:279;s:33:\"navigation-submenu/editor.min.css\";i:280;s:25:\"navigation/editor-rtl.css\";i:281;s:29:\"navigation/editor-rtl.min.css\";i:282;s:21:\"navigation/editor.css\";i:283;s:25:\"navigation/editor.min.css\";i:284;s:24:\"navigation/style-rtl.css\";i:285;s:28:\"navigation/style-rtl.min.css\";i:286;s:20:\"navigation/style.css\";i:287;s:24:\"navigation/style.min.css\";i:288;s:23:\"nextpage/editor-rtl.css\";i:289;s:27:\"nextpage/editor-rtl.min.css\";i:290;s:19:\"nextpage/editor.css\";i:291;s:23:\"nextpage/editor.min.css\";i:292;s:24:\"page-list/editor-rtl.css\";i:293;s:28:\"page-list/editor-rtl.min.css\";i:294;s:20:\"page-list/editor.css\";i:295;s:24:\"page-list/editor.min.css\";i:296;s:23:\"page-list/style-rtl.css\";i:297;s:27:\"page-list/style-rtl.min.css\";i:298;s:19:\"page-list/style.css\";i:299;s:23:\"page-list/style.min.css\";i:300;s:24:\"paragraph/editor-rtl.css\";i:301;s:28:\"paragraph/editor-rtl.min.css\";i:302;s:20:\"paragraph/editor.css\";i:303;s:24:\"paragraph/editor.min.css\";i:304;s:23:\"paragraph/style-rtl.css\";i:305;s:27:\"paragraph/style-rtl.min.css\";i:306;s:19:\"paragraph/style.css\";i:307;s:23:\"paragraph/style.min.css\";i:308;s:35:\"post-author-biography/style-rtl.css\";i:309;s:39:\"post-author-biography/style-rtl.min.css\";i:310;s:31:\"post-author-biography/style.css\";i:311;s:35:\"post-author-biography/style.min.css\";i:312;s:30:\"post-author-name/style-rtl.css\";i:313;s:34:\"post-author-name/style-rtl.min.css\";i:314;s:26:\"post-author-name/style.css\";i:315;s:30:\"post-author-name/style.min.css\";i:316;s:25:\"post-author/style-rtl.css\";i:317;s:29:\"post-author/style-rtl.min.css\";i:318;s:21:\"post-author/style.css\";i:319;s:25:\"post-author/style.min.css\";i:320;s:33:\"post-comments-count/style-rtl.css\";i:321;s:37:\"post-comments-count/style-rtl.min.css\";i:322;s:29:\"post-comments-count/style.css\";i:323;s:33:\"post-comments-count/style.min.css\";i:324;s:33:\"post-comments-form/editor-rtl.css\";i:325;s:37:\"post-comments-form/editor-rtl.min.css\";i:326;s:29:\"post-comments-form/editor.css\";i:327;s:33:\"post-comments-form/editor.min.css\";i:328;s:32:\"post-comments-form/style-rtl.css\";i:329;s:36:\"post-comments-form/style-rtl.min.css\";i:330;s:28:\"post-comments-form/style.css\";i:331;s:32:\"post-comments-form/style.min.css\";i:332;s:32:\"post-comments-link/style-rtl.css\";i:333;s:36:\"post-comments-link/style-rtl.min.css\";i:334;s:28:\"post-comments-link/style.css\";i:335;s:32:\"post-comments-link/style.min.css\";i:336;s:26:\"post-content/style-rtl.css\";i:337;s:30:\"post-content/style-rtl.min.css\";i:338;s:22:\"post-content/style.css\";i:339;s:26:\"post-content/style.min.css\";i:340;s:23:\"post-date/style-rtl.css\";i:341;s:27:\"post-date/style-rtl.min.css\";i:342;s:19:\"post-date/style.css\";i:343;s:23:\"post-date/style.min.css\";i:344;s:27:\"post-excerpt/editor-rtl.css\";i:345;s:31:\"post-excerpt/editor-rtl.min.css\";i:346;s:23:\"post-excerpt/editor.css\";i:347;s:27:\"post-excerpt/editor.min.css\";i:348;s:26:\"post-excerpt/style-rtl.css\";i:349;s:30:\"post-excerpt/style-rtl.min.css\";i:350;s:22:\"post-excerpt/style.css\";i:351;s:26:\"post-excerpt/style.min.css\";i:352;s:34:\"post-featured-image/editor-rtl.css\";i:353;s:38:\"post-featured-image/editor-rtl.min.css\";i:354;s:30:\"post-featured-image/editor.css\";i:355;s:34:\"post-featured-image/editor.min.css\";i:356;s:33:\"post-featured-image/style-rtl.css\";i:357;s:37:\"post-featured-image/style-rtl.min.css\";i:358;s:29:\"post-featured-image/style.css\";i:359;s:33:\"post-featured-image/style.min.css\";i:360;s:34:\"post-navigation-link/style-rtl.css\";i:361;s:38:\"post-navigation-link/style-rtl.min.css\";i:362;s:30:\"post-navigation-link/style.css\";i:363;s:34:\"post-navigation-link/style.min.css\";i:364;s:27:\"post-template/style-rtl.css\";i:365;s:31:\"post-template/style-rtl.min.css\";i:366;s:23:\"post-template/style.css\";i:367;s:27:\"post-template/style.min.css\";i:368;s:24:\"post-terms/style-rtl.css\";i:369;s:28:\"post-terms/style-rtl.min.css\";i:370;s:20:\"post-terms/style.css\";i:371;s:24:\"post-terms/style.min.css\";i:372;s:31:\"post-time-to-read/style-rtl.css\";i:373;s:35:\"post-time-to-read/style-rtl.min.css\";i:374;s:27:\"post-time-to-read/style.css\";i:375;s:31:\"post-time-to-read/style.min.css\";i:376;s:24:\"post-title/style-rtl.css\";i:377;s:28:\"post-title/style-rtl.min.css\";i:378;s:20:\"post-title/style.css\";i:379;s:24:\"post-title/style.min.css\";i:380;s:26:\"preformatted/style-rtl.css\";i:381;s:30:\"preformatted/style-rtl.min.css\";i:382;s:22:\"preformatted/style.css\";i:383;s:26:\"preformatted/style.min.css\";i:384;s:24:\"pullquote/editor-rtl.css\";i:385;s:28:\"pullquote/editor-rtl.min.css\";i:386;s:20:\"pullquote/editor.css\";i:387;s:24:\"pullquote/editor.min.css\";i:388;s:23:\"pullquote/style-rtl.css\";i:389;s:27:\"pullquote/style-rtl.min.css\";i:390;s:19:\"pullquote/style.css\";i:391;s:23:\"pullquote/style.min.css\";i:392;s:23:\"pullquote/theme-rtl.css\";i:393;s:27:\"pullquote/theme-rtl.min.css\";i:394;s:19:\"pullquote/theme.css\";i:395;s:23:\"pullquote/theme.min.css\";i:396;s:39:\"query-pagination-numbers/editor-rtl.css\";i:397;s:43:\"query-pagination-numbers/editor-rtl.min.css\";i:398;s:35:\"query-pagination-numbers/editor.css\";i:399;s:39:\"query-pagination-numbers/editor.min.css\";i:400;s:31:\"query-pagination/editor-rtl.css\";i:401;s:35:\"query-pagination/editor-rtl.min.css\";i:402;s:27:\"query-pagination/editor.css\";i:403;s:31:\"query-pagination/editor.min.css\";i:404;s:30:\"query-pagination/style-rtl.css\";i:405;s:34:\"query-pagination/style-rtl.min.css\";i:406;s:26:\"query-pagination/style.css\";i:407;s:30:\"query-pagination/style.min.css\";i:408;s:25:\"query-title/style-rtl.css\";i:409;s:29:\"query-title/style-rtl.min.css\";i:410;s:21:\"query-title/style.css\";i:411;s:25:\"query-title/style.min.css\";i:412;s:25:\"query-total/style-rtl.css\";i:413;s:29:\"query-total/style-rtl.min.css\";i:414;s:21:\"query-total/style.css\";i:415;s:25:\"query-total/style.min.css\";i:416;s:20:\"query/editor-rtl.css\";i:417;s:24:\"query/editor-rtl.min.css\";i:418;s:16:\"query/editor.css\";i:419;s:20:\"query/editor.min.css\";i:420;s:19:\"quote/style-rtl.css\";i:421;s:23:\"quote/style-rtl.min.css\";i:422;s:15:\"quote/style.css\";i:423;s:19:\"quote/style.min.css\";i:424;s:19:\"quote/theme-rtl.css\";i:425;s:23:\"quote/theme-rtl.min.css\";i:426;s:15:\"quote/theme.css\";i:427;s:19:\"quote/theme.min.css\";i:428;s:23:\"read-more/style-rtl.css\";i:429;s:27:\"read-more/style-rtl.min.css\";i:430;s:19:\"read-more/style.css\";i:431;s:23:\"read-more/style.min.css\";i:432;s:18:\"rss/editor-rtl.css\";i:433;s:22:\"rss/editor-rtl.min.css\";i:434;s:14:\"rss/editor.css\";i:435;s:18:\"rss/editor.min.css\";i:436;s:17:\"rss/style-rtl.css\";i:437;s:21:\"rss/style-rtl.min.css\";i:438;s:13:\"rss/style.css\";i:439;s:17:\"rss/style.min.css\";i:440;s:21:\"search/editor-rtl.css\";i:441;s:25:\"search/editor-rtl.min.css\";i:442;s:17:\"search/editor.css\";i:443;s:21:\"search/editor.min.css\";i:444;s:20:\"search/style-rtl.css\";i:445;s:24:\"search/style-rtl.min.css\";i:446;s:16:\"search/style.css\";i:447;s:20:\"search/style.min.css\";i:448;s:20:\"search/theme-rtl.css\";i:449;s:24:\"search/theme-rtl.min.css\";i:450;s:16:\"search/theme.css\";i:451;s:20:\"search/theme.min.css\";i:452;s:24:\"separator/editor-rtl.css\";i:453;s:28:\"separator/editor-rtl.min.css\";i:454;s:20:\"separator/editor.css\";i:455;s:24:\"separator/editor.min.css\";i:456;s:23:\"separator/style-rtl.css\";i:457;s:27:\"separator/style-rtl.min.css\";i:458;s:19:\"separator/style.css\";i:459;s:23:\"separator/style.min.css\";i:460;s:23:\"separator/theme-rtl.css\";i:461;s:27:\"separator/theme-rtl.min.css\";i:462;s:19:\"separator/theme.css\";i:463;s:23:\"separator/theme.min.css\";i:464;s:24:\"shortcode/editor-rtl.css\";i:465;s:28:\"shortcode/editor-rtl.min.css\";i:466;s:20:\"shortcode/editor.css\";i:467;s:24:\"shortcode/editor.min.css\";i:468;s:24:\"site-logo/editor-rtl.css\";i:469;s:28:\"site-logo/editor-rtl.min.css\";i:470;s:20:\"site-logo/editor.css\";i:471;s:24:\"site-logo/editor.min.css\";i:472;s:23:\"site-logo/style-rtl.css\";i:473;s:27:\"site-logo/style-rtl.min.css\";i:474;s:19:\"site-logo/style.css\";i:475;s:23:\"site-logo/style.min.css\";i:476;s:27:\"site-tagline/editor-rtl.css\";i:477;s:31:\"site-tagline/editor-rtl.min.css\";i:478;s:23:\"site-tagline/editor.css\";i:479;s:27:\"site-tagline/editor.min.css\";i:480;s:26:\"site-tagline/style-rtl.css\";i:481;s:30:\"site-tagline/style-rtl.min.css\";i:482;s:22:\"site-tagline/style.css\";i:483;s:26:\"site-tagline/style.min.css\";i:484;s:25:\"site-title/editor-rtl.css\";i:485;s:29:\"site-title/editor-rtl.min.css\";i:486;s:21:\"site-title/editor.css\";i:487;s:25:\"site-title/editor.min.css\";i:488;s:24:\"site-title/style-rtl.css\";i:489;s:28:\"site-title/style-rtl.min.css\";i:490;s:20:\"site-title/style.css\";i:491;s:24:\"site-title/style.min.css\";i:492;s:26:\"social-link/editor-rtl.css\";i:493;s:30:\"social-link/editor-rtl.min.css\";i:494;s:22:\"social-link/editor.css\";i:495;s:26:\"social-link/editor.min.css\";i:496;s:27:\"social-links/editor-rtl.css\";i:497;s:31:\"social-links/editor-rtl.min.css\";i:498;s:23:\"social-links/editor.css\";i:499;s:27:\"social-links/editor.min.css\";i:500;s:26:\"social-links/style-rtl.css\";i:501;s:30:\"social-links/style-rtl.min.css\";i:502;s:22:\"social-links/style.css\";i:503;s:26:\"social-links/style.min.css\";i:504;s:21:\"spacer/editor-rtl.css\";i:505;s:25:\"spacer/editor-rtl.min.css\";i:506;s:17:\"spacer/editor.css\";i:507;s:21:\"spacer/editor.min.css\";i:508;s:20:\"spacer/style-rtl.css\";i:509;s:24:\"spacer/style-rtl.min.css\";i:510;s:16:\"spacer/style.css\";i:511;s:20:\"spacer/style.min.css\";i:512;s:20:\"table/editor-rtl.css\";i:513;s:24:\"table/editor-rtl.min.css\";i:514;s:16:\"table/editor.css\";i:515;s:20:\"table/editor.min.css\";i:516;s:19:\"table/style-rtl.css\";i:517;s:23:\"table/style-rtl.min.css\";i:518;s:15:\"table/style.css\";i:519;s:19:\"table/style.min.css\";i:520;s:19:\"table/theme-rtl.css\";i:521;s:23:\"table/theme-rtl.min.css\";i:522;s:15:\"table/theme.css\";i:523;s:19:\"table/theme.min.css\";i:524;s:24:\"tag-cloud/editor-rtl.css\";i:525;s:28:\"tag-cloud/editor-rtl.min.css\";i:526;s:20:\"tag-cloud/editor.css\";i:527;s:24:\"tag-cloud/editor.min.css\";i:528;s:23:\"tag-cloud/style-rtl.css\";i:529;s:27:\"tag-cloud/style-rtl.min.css\";i:530;s:19:\"tag-cloud/style.css\";i:531;s:23:\"tag-cloud/style.min.css\";i:532;s:28:\"template-part/editor-rtl.css\";i:533;s:32:\"template-part/editor-rtl.min.css\";i:534;s:24:\"template-part/editor.css\";i:535;s:28:\"template-part/editor.min.css\";i:536;s:27:\"template-part/theme-rtl.css\";i:537;s:31:\"template-part/theme-rtl.min.css\";i:538;s:23:\"template-part/theme.css\";i:539;s:27:\"template-part/theme.min.css\";i:540;s:24:\"term-count/style-rtl.css\";i:541;s:28:\"term-count/style-rtl.min.css\";i:542;s:20:\"term-count/style.css\";i:543;s:24:\"term-count/style.min.css\";i:544;s:30:\"term-description/style-rtl.css\";i:545;s:34:\"term-description/style-rtl.min.css\";i:546;s:26:\"term-description/style.css\";i:547;s:30:\"term-description/style.min.css\";i:548;s:23:\"term-name/style-rtl.css\";i:549;s:27:\"term-name/style-rtl.min.css\";i:550;s:19:\"term-name/style.css\";i:551;s:23:\"term-name/style.min.css\";i:552;s:28:\"term-template/editor-rtl.css\";i:553;s:32:\"term-template/editor-rtl.min.css\";i:554;s:24:\"term-template/editor.css\";i:555;s:28:\"term-template/editor.min.css\";i:556;s:27:\"term-template/style-rtl.css\";i:557;s:31:\"term-template/style-rtl.min.css\";i:558;s:23:\"term-template/style.css\";i:559;s:27:\"term-template/style.min.css\";i:560;s:27:\"text-columns/editor-rtl.css\";i:561;s:31:\"text-columns/editor-rtl.min.css\";i:562;s:23:\"text-columns/editor.css\";i:563;s:27:\"text-columns/editor.min.css\";i:564;s:26:\"text-columns/style-rtl.css\";i:565;s:30:\"text-columns/style-rtl.min.css\";i:566;s:22:\"text-columns/style.css\";i:567;s:26:\"text-columns/style.min.css\";i:568;s:19:\"verse/style-rtl.css\";i:569;s:23:\"verse/style-rtl.min.css\";i:570;s:15:\"verse/style.css\";i:571;s:19:\"verse/style.min.css\";i:572;s:20:\"video/editor-rtl.css\";i:573;s:24:\"video/editor-rtl.min.css\";i:574;s:16:\"video/editor.css\";i:575;s:20:\"video/editor.min.css\";i:576;s:19:\"video/style-rtl.css\";i:577;s:23:\"video/style-rtl.min.css\";i:578;s:15:\"video/style.css\";i:579;s:19:\"video/style.min.css\";i:580;s:19:\"video/theme-rtl.css\";i:581;s:23:\"video/theme-rtl.min.css\";i:582;s:15:\"video/theme.css\";i:583;s:19:\"video/theme.min.css\";}}','on'),
(127,'recovery_keys','a:0:{}','off'),
(138,'can_compress_scripts','0','on'),
(155,'finished_updating_comment_type','1','auto'),
(156,'WPLANG','fr_FR','auto'),
(157,'new_admin_email','othman.bensaoula@gmail.com','auto'),
(160,'theme_mods_twentytwentyfive','a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1771177716;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}','off'),
(161,'current_theme','Sage Starter Theme','auto'),
(162,'theme_mods_sage','a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}','on'),
(163,'theme_switched','','auto'),
(166,'_transient_wp_styles_for_blocks','a:2:{s:4:\"hash\";s:32:\"3d5ec78bc4443a2a7017790e8e80ca84\";s:6:\"blocks\";a:6:{s:11:\"core/button\";s:0:\"\";s:14:\"core/site-logo\";s:0:\"\";s:18:\"core/post-template\";s:120:\":where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}\";s:18:\"core/term-template\";s:120:\":where(.wp-block-term-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-term-template.is-layout-grid){gap: 1.25em;}\";s:12:\"core/columns\";s:102:\":where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}\";s:14:\"core/pullquote\";s:69:\":root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}\";}}','on'),
(183,'nav_menu_options','a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}','off'),
(189,'_site_transient_wp_plugin_dependencies_plugin_data','a:0:{}','off'),
(190,'recently_activated','a:0:{}','off'),
(191,'acf_first_activated_version','6.7.0','on'),
(192,'acf_site_health','{\"version\":\"6.7.0.2\",\"plugin_type\":\"PRO\",\"update_source\":\"ACF Direct\",\"activated\":true,\"activated_url\":\"https:\\/\\/chloecrase.ddev.site\",\"license_type\":\"Agency\",\"license_status\":\"active\",\"subscription_expires\":\"\",\"wp_version\":\"6.9.1\",\"mysql_version\":\"10.11.14-MariaDB-ubu2204-log\",\"is_multisite\":false,\"active_theme\":{\"name\":\"Sage Starter Theme\",\"version\":\"11.0.1\",\"theme_uri\":\"https:\\/\\/roots.io\\/sage\\/\",\"stylesheet\":false},\"active_plugins\":{\"advanced-custom-fields-pro\\/acf.php\":{\"name\":\"Advanced Custom Fields PRO\",\"version\":\"6.7.0.2\",\"plugin_uri\":\"https:\\/\\/www.advancedcustomfields.com\"},\"litespeed-cache\\/litespeed-cache.php\":{\"name\":\"LiteSpeed Cache\",\"version\":\"7.7\",\"plugin_uri\":\"https:\\/\\/www.litespeedtech.com\\/products\\/cache-plugins\\/wordpress-acceleration\"}},\"ui_field_groups\":\"0\",\"php_field_groups\":\"0\",\"json_field_groups\":\"0\",\"rest_field_groups\":\"0\",\"all_location_rules\":[\"post_type==project\",\"page_type==front_page\"],\"field_groups_with_single_block_rule\":\"0\",\"field_groups_with_multiple_block_rules\":\"0\",\"field_groups_with_blocks_and_other_rules\":\"0\",\"number_of_fields_by_type\":{\"text\":2,\"repeater\":1,\"tab\":2,\"wysiwyg\":3,\"relationship\":1,\"image\":1},\"number_of_third_party_fields_by_type\":[],\"post_types_enabled\":true,\"ui_post_types\":\"4\",\"json_post_types\":\"0\",\"ui_taxonomies\":\"4\",\"json_taxonomies\":\"0\",\"ui_options_pages_enabled\":true,\"ui_options_pages\":\"0\",\"json_options_pages\":\"0\",\"php_options_pages\":\"0\",\"rest_api_format\":\"light\",\"registered_acf_blocks\":\"0\",\"blocks_per_api_version\":[],\"blocks_per_acf_block_version\":[],\"blocks_using_post_meta\":\"0\",\"blocks_using_auto_inline_editing\":\"0\",\"preload_blocks\":true,\"admin_ui_enabled\":true,\"field_type-modal_enabled\":true,\"field_settings_tabs_enabled\":false,\"shortcode_enabled\":false,\"registered_acf_forms\":\"0\",\"json_save_paths\":1,\"json_load_paths\":1,\"event_first_activated\":1771185104,\"last_updated\":1771935153}','off'),
(194,'acf_version','6.7.0.2','auto'),
(214,'recovery_mode_email_last_sent','1771188442','auto'),
(227,'_transient_health-check-site-status-result','{\"good\":15,\"recommended\":5,\"critical\":1}','on'),
(285,'project_category_children','a:0:{}','auto'),
(303,'acf_pro_license','YToyOntzOjM6ImtleSI7czozMjoiR1BMMDAxMTIyMzM0NDU1QUE2Njc3QkI4ODk5Q0MwMDAiO3M6MzoidXJsIjtzOjI4OiJodHRwczovL2NobG9lY3Jhc2UuZGRldi5zaXRlIjt9','off'),
(304,'acf_pro_license_status','a:10:{s:6:\"status\";s:6:\"active\";s:7:\"created\";i:0;s:6:\"expiry\";i:0;s:4:\"name\";s:6:\"Agency\";s:8:\"lifetime\";b:1;s:8:\"refunded\";b:0;s:17:\"view_licenses_url\";s:62:\"https://www.advancedcustomfields.com/my-account/view-licenses/\";s:23:\"manage_subscription_url\";s:0:\"\";s:9:\"error_msg\";s:0:\"\";s:10:\"next_check\";i:1772138177;}','on'),
(331,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/fr_FR/wordpress-6.9.1.zip\";s:6:\"locale\";s:5:\"fr_FR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/fr_FR/wordpress-6.9.1.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.9.1\";s:7:\"version\";s:5:\"6.9.1\";s:11:\"php_version\";s:6:\"7.2.24\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1772133428;s:15:\"version_checked\";s:5:\"6.9.1\";s:12:\"translations\";a:0:{}}','off'),
(332,'_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1772133429;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:2:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"6.7.0\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.6.7.0.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:67:\"https://ps.w.org/advanced-custom-fields/assets/icon.svg?rev=3207824\";s:3:\"svg\";s:67:\"https://ps.w.org/advanced-custom-fields/assets/icon.svg?rev=3207824\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=3374528\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=3374528\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"6.2\";}s:35:\"litespeed-cache/litespeed-cache.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:29:\"w.org/plugins/litespeed-cache\";s:4:\"slug\";s:15:\"litespeed-cache\";s:6:\"plugin\";s:35:\"litespeed-cache/litespeed-cache.php\";s:11:\"new_version\";s:3:\"7.7\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/litespeed-cache/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/litespeed-cache.7.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/litespeed-cache/assets/icon-256x256.png?rev=2554181\";s:2:\"1x\";s:68:\"https://ps.w.org/litespeed-cache/assets/icon-128x128.png?rev=2554181\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/litespeed-cache/assets/banner-1544x500.png?rev=2554181\";s:2:\"1x\";s:70:\"https://ps.w.org/litespeed-cache/assets/banner-772x250.png?rev=2554181\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.3\";}}s:7:\"checked\";a:3:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"6.7.0\";s:34:\"advanced-custom-fields-pro/acf.php\";s:7:\"6.7.0.2\";s:35:\"litespeed-cache/litespeed-cache.php\";s:3:\"7.7\";}}','off'),
(333,'_site_transient_update_themes','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1772134902;s:7:\"checked\";a:1:{s:4:\"sage\";s:6:\"11.0.1\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}','off'),
(334,'litespeed.conf._version','7.7','auto'),
(335,'litespeed.conf.hash','SM5jEBFBHGDtgV4cf2eEf1hR8DMav17k','auto'),
(336,'litespeed.conf.api_key','','auto'),
(337,'litespeed.conf.auto_upgrade','','auto'),
(338,'litespeed.conf.server_ip','','auto'),
(339,'litespeed.conf.guest','','auto'),
(340,'litespeed.conf.guest_optm','','auto'),
(341,'litespeed.conf.news','1','auto'),
(342,'litespeed.conf.cache','1','auto'),
(343,'litespeed.conf.cache-priv','1','auto'),
(344,'litespeed.conf.cache-commenter','1','auto'),
(345,'litespeed.conf.cache-rest','1','auto'),
(346,'litespeed.conf.cache-page_login','1','auto'),
(347,'litespeed.conf.cache-mobile','','auto'),
(348,'litespeed.conf.cache-mobile_rules','[\"Mobile\",\"Android\",\"Silk\\/\",\"Kindle\",\"BlackBerry\",\"Opera Mini\",\"Opera Mobi\"]','auto'),
(349,'litespeed.conf.cache-browser','','auto'),
(350,'litespeed.conf.cache-exc_useragents','[]','auto'),
(351,'litespeed.conf.cache-exc_cookies','[]','auto'),
(352,'litespeed.conf.cache-exc_qs','[]','auto'),
(353,'litespeed.conf.cache-exc_cat','[]','auto'),
(354,'litespeed.conf.cache-exc_tag','[]','auto'),
(355,'litespeed.conf.cache-force_uri','[]','auto'),
(356,'litespeed.conf.cache-force_pub_uri','[]','auto'),
(357,'litespeed.conf.cache-priv_uri','[]','auto'),
(358,'litespeed.conf.cache-exc','[]','auto'),
(359,'litespeed.conf.cache-exc_roles','[]','auto'),
(360,'litespeed.conf.cache-drop_qs','[\"fbclid\",\"gclid\",\"utm*\",\"_ga\"]','auto'),
(361,'litespeed.conf.cache-ttl_pub','604800','auto'),
(362,'litespeed.conf.cache-ttl_priv','1800','auto'),
(363,'litespeed.conf.cache-ttl_frontpage','604800','auto'),
(364,'litespeed.conf.cache-ttl_feed','604800','auto'),
(365,'litespeed.conf.cache-ttl_rest','604800','auto'),
(366,'litespeed.conf.cache-ttl_browser','31557600','auto'),
(367,'litespeed.conf.cache-ttl_status','[\"404 3600\",\"500 600\"]','auto'),
(368,'litespeed.conf.cache-login_cookie','','auto'),
(369,'litespeed.conf.cache-ajax_ttl','[]','auto'),
(370,'litespeed.conf.cache-vary_cookies','[]','auto'),
(371,'litespeed.conf.cache-vary_group','[]','auto'),
(372,'litespeed.conf.purge-upgrade','','auto'),
(373,'litespeed.conf.purge-stale','','auto'),
(374,'litespeed.conf.purge-post_all','','auto'),
(375,'litespeed.conf.purge-post_f','1','auto'),
(376,'litespeed.conf.purge-post_h','1','auto'),
(377,'litespeed.conf.purge-post_p','1','auto'),
(378,'litespeed.conf.purge-post_pwrp','1','auto'),
(379,'litespeed.conf.purge-post_a','1','auto'),
(380,'litespeed.conf.purge-post_y','','auto'),
(381,'litespeed.conf.purge-post_m','1','auto'),
(382,'litespeed.conf.purge-post_d','','auto'),
(383,'litespeed.conf.purge-post_t','1','auto'),
(384,'litespeed.conf.purge-post_pt','1','auto'),
(385,'litespeed.conf.purge-timed_urls','[]','auto'),
(386,'litespeed.conf.purge-timed_urls_time','','auto'),
(387,'litespeed.conf.purge-hook_all','[\"switch_theme\",\"wp_create_nav_menu\",\"wp_update_nav_menu\",\"wp_delete_nav_menu\",\"create_term\",\"edit_terms\",\"delete_term\",\"add_link\",\"edit_link\",\"delete_link\"]','auto'),
(388,'litespeed.conf.esi','','auto'),
(389,'litespeed.conf.esi-cache_admbar','1','auto'),
(390,'litespeed.conf.esi-cache_commform','1','auto'),
(391,'litespeed.conf.esi-nonce','[\"stats_nonce\",\"subscribe_nonce\"]','auto'),
(392,'litespeed.conf.util-instant_click','','auto'),
(393,'litespeed.conf.util-no_https_vary','','auto'),
(394,'litespeed.conf.debug-disable_all','','auto'),
(395,'litespeed.conf.debug','0','auto'),
(396,'litespeed.conf.debug-ips','[\"127.0.0.1\"]','auto'),
(397,'litespeed.conf.debug-level','','auto'),
(398,'litespeed.conf.debug-filesize','3','auto'),
(399,'litespeed.conf.debug-collapse_qs','','auto'),
(400,'litespeed.conf.debug-inc','[]','auto'),
(401,'litespeed.conf.debug-exc','[]','auto'),
(402,'litespeed.conf.debug-exc_strings','[]','auto'),
(403,'litespeed.conf.db_optm-revisions_max','0','auto'),
(404,'litespeed.conf.db_optm-revisions_age','0','auto'),
(405,'litespeed.conf.optm-css_min','','auto'),
(406,'litespeed.conf.optm-css_comb','','auto'),
(407,'litespeed.conf.optm-css_comb_ext_inl','1','auto'),
(408,'litespeed.conf.optm-ucss','','auto'),
(409,'litespeed.conf.optm-ucss_inline','','auto'),
(410,'litespeed.conf.optm-ucss_whitelist','[]','auto'),
(411,'litespeed.conf.optm-ucss_file_exc_inline','[]','auto'),
(412,'litespeed.conf.optm-ucss_exc','[]','auto'),
(413,'litespeed.conf.optm-css_exc','[]','auto'),
(414,'litespeed.conf.optm-js_min','','auto'),
(415,'litespeed.conf.optm-js_comb','','auto'),
(416,'litespeed.conf.optm-js_comb_ext_inl','1','auto'),
(417,'litespeed.conf.optm-js_delay_inc','[]','auto'),
(418,'litespeed.conf.optm-js_exc','[\"jquery.js\",\"jquery.min.js\"]','auto'),
(419,'litespeed.conf.optm-html_min','','auto'),
(420,'litespeed.conf.optm-html_lazy','[]','auto'),
(421,'litespeed.conf.optm-html_skip_comment','[]','auto'),
(422,'litespeed.conf.optm-qs_rm','','auto'),
(423,'litespeed.conf.optm-ggfonts_rm','','auto'),
(424,'litespeed.conf.optm-css_async','','auto'),
(425,'litespeed.conf.optm-ccss_per_url','','auto'),
(426,'litespeed.conf.optm-ccss_sep_posttype','[\"page\"]','auto'),
(427,'litespeed.conf.optm-ccss_sep_uri','[]','auto'),
(428,'litespeed.conf.optm-ccss_whitelist','[]','auto'),
(429,'litespeed.conf.optm-css_async_inline','1','auto'),
(430,'litespeed.conf.optm-css_font_display','','auto'),
(431,'litespeed.conf.optm-js_defer','0','auto'),
(432,'litespeed.conf.optm-emoji_rm','','auto'),
(433,'litespeed.conf.optm-noscript_rm','','auto'),
(434,'litespeed.conf.optm-ggfonts_async','','auto'),
(435,'litespeed.conf.optm-exc_roles','[]','auto'),
(436,'litespeed.conf.optm-ccss_con','','auto'),
(437,'litespeed.conf.optm-js_defer_exc','[\"jquery.js\",\"jquery.min.js\",\"gtm.js\",\"analytics.js\"]','auto'),
(438,'litespeed.conf.optm-gm_js_exc','[]','auto'),
(439,'litespeed.conf.optm-dns_prefetch','[]','auto'),
(440,'litespeed.conf.optm-dns_prefetch_ctrl','','auto'),
(441,'litespeed.conf.optm-dns_preconnect','[]','auto'),
(442,'litespeed.conf.optm-exc','[]','auto'),
(443,'litespeed.conf.optm-guest_only','1','auto'),
(444,'litespeed.conf.object','','auto'),
(445,'litespeed.conf.object-kind','','auto'),
(446,'litespeed.conf.object-host','localhost','auto'),
(447,'litespeed.conf.object-port','11211','auto'),
(448,'litespeed.conf.object-life','360','auto'),
(449,'litespeed.conf.object-persistent','1','auto'),
(450,'litespeed.conf.object-admin','1','auto'),
(451,'litespeed.conf.object-transients','1','auto'),
(452,'litespeed.conf.object-db_id','0','auto'),
(453,'litespeed.conf.object-user','','auto'),
(454,'litespeed.conf.object-pswd','','auto'),
(455,'litespeed.conf.object-global_groups','[\"users\",\"userlogins\",\"useremail\",\"userslugs\",\"usermeta\",\"user_meta\",\"site-transient\",\"site-options\",\"site-lookup\",\"site-details\",\"blog-lookup\",\"blog-details\",\"blog-id-cache\",\"rss\",\"global-posts\",\"global-cache-test\"]','auto'),
(456,'litespeed.conf.object-non_persistent_groups','[\"comment\",\"counts\",\"plugins\",\"wc_session_id\"]','auto'),
(457,'litespeed.conf.discuss-avatar_cache','','auto'),
(458,'litespeed.conf.discuss-avatar_cron','','auto'),
(459,'litespeed.conf.discuss-avatar_cache_ttl','604800','auto'),
(460,'litespeed.conf.optm-localize','','auto'),
(461,'litespeed.conf.optm-localize_domains','[\"### Popular scripts ###\",\"https:\\/\\/platform.twitter.com\\/widgets.js\",\"https:\\/\\/connect.facebook.net\\/en_US\\/fbevents.js\"]','auto'),
(462,'litespeed.conf.media-lazy','','auto'),
(463,'litespeed.conf.media-lazy_placeholder','','auto'),
(464,'litespeed.conf.media-placeholder_resp','','auto'),
(465,'litespeed.conf.media-placeholder_resp_color','#cfd4db','auto'),
(466,'litespeed.conf.media-placeholder_resp_svg','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\"><rect width=\"100%\" height=\"100%\" style=\"fill:{color};fill-opacity: 0.1;\"/></svg>','auto'),
(467,'litespeed.conf.media-lqip','','auto'),
(468,'litespeed.conf.media-lqip_qual','4','auto'),
(469,'litespeed.conf.media-lqip_min_w','150','auto'),
(470,'litespeed.conf.media-lqip_min_h','150','auto'),
(471,'litespeed.conf.media-placeholder_resp_async','1','auto'),
(472,'litespeed.conf.media-iframe_lazy','','auto'),
(473,'litespeed.conf.media-add_missing_sizes','','auto'),
(474,'litespeed.conf.media-lazy_exc','[]','auto'),
(475,'litespeed.conf.media-lazy_cls_exc','[\"wmu-preview-img\"]','auto'),
(476,'litespeed.conf.media-lazy_parent_cls_exc','[]','auto'),
(477,'litespeed.conf.media-iframe_lazy_cls_exc','[]','auto'),
(478,'litespeed.conf.media-iframe_lazy_parent_cls_exc','[]','auto'),
(479,'litespeed.conf.media-lazy_uri_exc','[]','auto'),
(480,'litespeed.conf.media-lqip_exc','[]','auto'),
(481,'litespeed.conf.media-vpi','','auto'),
(482,'litespeed.conf.media-vpi_cron','','auto'),
(483,'litespeed.conf.media-auto_rescale_ori','','auto'),
(484,'litespeed.conf.img_optm-auto','','auto'),
(485,'litespeed.conf.img_optm-ori','1','auto'),
(486,'litespeed.conf.img_optm-rm_bkup','','auto'),
(487,'litespeed.conf.img_optm-webp','1','auto'),
(488,'litespeed.conf.img_optm-lossless','','auto'),
(489,'litespeed.conf.img_optm-sizes_skipped','[]','auto'),
(490,'litespeed.conf.img_optm-exif','1','auto'),
(491,'litespeed.conf.img_optm-webp_attr','[\"img.src\",\"div.data-thumb\",\"img.data-src\",\"img.data-lazyload\",\"div.data-large_image\",\"img.retina_logo_url\",\"div.data-parallax-image\",\"div.data-vc-parallax-image\",\"video.poster\"]','auto'),
(492,'litespeed.conf.img_optm-webp_replace_srcset','','auto'),
(493,'litespeed.conf.img_optm-jpg_quality','82','auto'),
(494,'litespeed.conf.crawler','','auto'),
(495,'litespeed.conf.crawler-crawl_interval','302400','auto'),
(496,'litespeed.conf.crawler-load_limit','1','auto'),
(497,'litespeed.conf.crawler-sitemap','','auto'),
(498,'litespeed.conf.crawler-roles','[]','auto'),
(499,'litespeed.conf.crawler-cookies','[]','auto'),
(500,'litespeed.conf.misc-heartbeat_front','','auto'),
(501,'litespeed.conf.misc-heartbeat_front_ttl','60','auto'),
(502,'litespeed.conf.misc-heartbeat_back','','auto'),
(503,'litespeed.conf.misc-heartbeat_back_ttl','60','auto'),
(504,'litespeed.conf.misc-heartbeat_editor','','auto'),
(505,'litespeed.conf.misc-heartbeat_editor_ttl','15','auto'),
(506,'litespeed.conf.cdn','','auto'),
(507,'litespeed.conf.cdn-ori','[]','auto'),
(508,'litespeed.conf.cdn-ori_dir','[\"https:\\/\\/chloecrase.ddev.site\\/app\",\"wp-includes\"]','auto'),
(509,'litespeed.conf.cdn-exc','[]','auto'),
(510,'litespeed.conf.cdn-quic','','auto'),
(511,'litespeed.conf.cdn-cloudflare','','auto'),
(512,'litespeed.conf.cdn-cloudflare_email','','auto'),
(513,'litespeed.conf.cdn-cloudflare_key','','auto'),
(514,'litespeed.conf.cdn-cloudflare_name','','auto'),
(515,'litespeed.conf.cdn-cloudflare_zone','','auto'),
(516,'litespeed.conf.cdn-cloudflare_clear','','auto'),
(517,'litespeed.conf.cdn-mapping','[{\"url\":\"\",\"inc_img\":\"1\",\"inc_css\":\"1\",\"inc_js\":\"1\",\"filetype\":[\".aac\",\".css\",\".eot\",\".gif\",\".jpeg\",\".jpg\",\".js\",\".less\",\".mp3\",\".mp4\",\".ogg\",\".otf\",\".pdf\",\".png\",\".svg\",\".ttf\",\".webp\",\".woff\",\".woff2\"]}]','auto'),
(518,'litespeed.conf.cdn-attr','[\".src\",\".data-src\",\".href\",\".poster\",\"source.srcset\"]','auto'),
(519,'litespeed.conf.qc-nameservers','','auto'),
(520,'litespeed.conf.qc-cname','','auto'),
(521,'litespeed.conf.debug-disable_tmp','0','auto'),
(522,'litespeed.cloud._summary','{\"curr_request.ver_check\":0,\"last_request.ver_check\":1771774239,\"news.utime\":1771774240,\"curr_request.news\":0,\"last_request.news\":1771774240,\"pk_b64\":\"5pjUp\\/PocxleqZpHVpE9ZEGzVqr1LpGEe1CewJknpqc=\",\"sk_b64\":\"RnNRgfSSWq9bR+7AB5Lvyu4MDE96faNvao1x5grOJRzmmNSn8+hzGV6pmkdWkT1kQbNWqvUukYR7UJ7AmSempw==\",\"curr_request.tool\\/wp_rest_echo\":1771774338,\"curr_request.d\\/dash\":0,\"mini_html\":{\"news_dash_guest\":\"\",\"ttl.news_dash_guest\":1772197937,\"promo_mini\":\"\",\"ttl.promo_mini\":1772140337},\"last_request.d\\/dash\":1772053936}','auto'),
(523,'litespeed.purge.queue','-1','auto'),
(524,'litespeed.purge.queue2','-1','auto'),
(525,'litespeed.gui.lscwp_whm_install','-1','auto'),
(526,'litespeed.gui.dismiss','-1','auto'),
(527,'litespeed.data.upgrading','-1','auto'),
(528,'litespeed.admin_display.messages','-1','auto'),
(529,'litespeed.gui._summary','{\"new_version\":1772379040,\"score\":1772983840}','auto'),
(531,'litespeed.crawler.bypass_list','[]','auto'),
(532,'litespeed.img_optm._summary','{\"next_post_id\":0,\"is_running\":0}','auto'),
(570,'_site_transient_timeout_php_check_9da3f9e285c18d164083488b0813f10b','1772539956','off'),
(571,'_site_transient_php_check_9da3f9e285c18d164083488b0813f10b','a:5:{s:19:\"recommended_version\";s:3:\"8.3\";s:15:\"minimum_version\";s:6:\"7.2.24\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}','off'),
(764,'options_option__whatsapp','https://wa.me/0659349675/?text=urlencodedtext','off'),
(765,'_options_option__whatsapp','field_191391d4','off'),
(766,'options_option__email','chloe.c1998@gmail.com','off'),
(767,'_options_option__email','field_4a820982','off'),
(768,'options_option__instagram','https://www.instagram.com/eclore_design?igsh=Z2gzZ203eGM0YnR2','off'),
(769,'_options_option__instagram','field_68b623b6','off'),
(770,'options_option__linkedin','https://www.linkedin.com/in/chlo%C3%A9-crase-2b948a170','off'),
(771,'_options_option__linkedin','field_144b5754','off'),
(833,'_site_transient_timeout_theme_roots','1772136701','off'),
(834,'_site_transient_theme_roots','a:1:{s:4:\"sage\";s:7:\"/themes\";}','off'),
(846,'_transient_timeout_acf_plugin_updates','1772137504','off'),
(847,'_transient_acf_plugin_updates','O:8:\"WP_Error\":3:{s:6:\"errors\";a:1:{s:12:\"server_error\";a:1:{i:0;s:9:\"Forbidden\";}}s:10:\"error_data\";a:0:{}s:18:\"\0*\0additional_data\";a:0:{}}','off'),
(851,'_transient_timeout_acf_pro_validating_license','1772138177','off'),
(852,'_transient_acf_pro_validating_license','1','off'),
(861,'_site_transient_timeout_wp_theme_files_patterns-845ff4fa35c49074dc9bb7efc998b52d','1772140665','off'),
(862,'_site_transient_wp_theme_files_patterns-845ff4fa35c49074dc9bb7efc998b52d','a:2:{s:7:\"version\";s:6:\"11.0.1\";s:8:\"patterns\";a:0:{}}','off');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=577 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES
(1,2,'_wp_page_template','default'),
(2,3,'_wp_page_template','default'),
(3,5,'_edit_lock','1772134322:1'),
(22,10,'_menu_item_type','custom'),
(23,10,'_menu_item_menu_item_parent','0'),
(24,10,'_menu_item_object_id','10'),
(25,10,'_menu_item_object','custom'),
(26,10,'_menu_item_target',''),
(27,10,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(28,10,'_menu_item_xfn',''),
(29,10,'_menu_item_url','/#projects'),
(31,11,'_menu_item_type','custom'),
(32,11,'_menu_item_menu_item_parent','0'),
(33,11,'_menu_item_object_id','11'),
(34,11,'_menu_item_object','custom'),
(35,11,'_menu_item_target',''),
(36,11,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(37,11,'_menu_item_xfn',''),
(38,11,'_menu_item_url','/#about'),
(40,5,'_edit_last','1'),
(41,5,'_wp_page_template','default'),
(42,5,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(43,5,'_home__title','field_55a225b4'),
(44,12,'home__title','Construire du sens, faire naître du désir'),
(45,12,'_home__title','field_55a225b4'),
(46,13,'home__title','Construire du <strong>sens</strong>, faire naître du <strong>désir</strong>'),
(47,13,'_home__title','field_55a225b4'),
(48,14,'home__title','Construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(49,14,'_home__title','field_55a225b4'),
(50,15,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(51,15,'_home__title','field_55a225b4'),
(52,16,'_edit_last','1'),
(53,16,'_edit_lock','1772136974:1'),
(56,18,'_wp_attached_file','2026/02/nbs-1.png'),
(57,18,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:17:\"2026/02/nbs-1.png\";s:8:\"filesize\";i:32056;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-1-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4148;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-1-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:14139;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2647;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-1-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10935;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-1-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:22774;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-1-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:23599;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-1-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:19996;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-1-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:15841;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-1-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10935;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-1-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:5466;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(58,19,'_wp_attached_file','2026/02/nbs-2.png'),
(59,19,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:17:\"2026/02/nbs-2.png\";s:8:\"filesize\";i:35074;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-2-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4547;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-2-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:16110;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2561;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-2-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:12867;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-2-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:26736;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-2-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:27920;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-2-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:24195;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-2-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:18457;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-2-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:12867;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-2-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:6180;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(60,20,'_wp_attached_file','2026/02/nbs-3.png'),
(61,20,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:17:\"2026/02/nbs-3.png\";s:8:\"filesize\";i:32713;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-3-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4158;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-3-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:16408;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2202;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-3-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:13251;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-3-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:26310;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-3-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:27380;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-3-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:23816;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-3-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:18740;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-3-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:13251;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-3-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:5974;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(62,21,'_wp_attached_file','2026/02/nbs-4-scaled.png'),
(63,21,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1271;s:4:\"file\";s:24:\"2026/02/nbs-4-scaled.png\";s:8:\"filesize\";i:3807429;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-4-300x149.png\";s:5:\"width\";i:300;s:6:\"height\";i:149;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:72699;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-4-1024x509.png\";s:5:\"width\";i:1024;s:6:\"height\";i:509;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:721748;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-4-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:38211;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-4-768x381.png\";s:5:\"width\";i:768;s:6:\"height\";i:381;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:416893;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:18:\"nbs-4-1536x763.png\";s:5:\"width\";i:1536;s:6:\"height\";i:763;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1515759;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:19:\"nbs-4-2048x1017.png\";s:5:\"width\";i:2048;s:6:\"height\";i:1017;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2513427;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:19:\"nbs-4-2560x1271.png\";s:5:\"width\";i:2560;s:6:\"height\";i:1271;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3807429;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:18:\"nbs-4-1920x953.png\";s:5:\"width\";i:1920;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2277493;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:18:\"nbs-4-1440x715.png\";s:5:\"width\";i:1440;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1349443;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:18:\"nbs-4-1280x636.png\";s:5:\"width\";i:1280;s:6:\"height\";i:636;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1092455;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:18:\"nbs-4-1024x509.png\";s:5:\"width\";i:1024;s:6:\"height\";i:509;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:721748;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-4-768x381.png\";s:5:\"width\";i:768;s:6:\"height\";i:381;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:416893;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-4-374x186.png\";s:5:\"width\";i:374;s:6:\"height\";i:186;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:109391;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:9:\"nbs-4.png\";}'),
(64,22,'_wp_attached_file','2026/02/nbs-5.png'),
(65,22,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:17:\"2026/02/nbs-5.png\";s:8:\"filesize\";i:1453571;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-5-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:22159;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-5-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:204036;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-5-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:8813;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-5-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:139800;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-5-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:442797;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-5-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:472568;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-5-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:374026;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-5-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:246009;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-5-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:139800;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-5-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:36321;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(66,23,'_wp_attached_file','2026/02/nbs-6.png'),
(67,23,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:17:\"2026/02/nbs-6.png\";s:8:\"filesize\";i:1051797;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-6-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:13291;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-6-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:84267;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-6-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:5997;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-6-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:61639;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-6-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:159822;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-6-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:179126;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-6-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:144631;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-6-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:100320;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-6-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:61639;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-6-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:21112;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(68,24,'_wp_attached_file','2026/02/nbs-7-scaled.png'),
(69,24,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1579;s:4:\"file\";s:24:\"2026/02/nbs-7-scaled.png\";s:8:\"filesize\";i:5534347;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-7-300x185.png\";s:5:\"width\";i:300;s:6:\"height\";i:185;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:113146;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-7-1024x632.png\";s:5:\"width\";i:1024;s:6:\"height\";i:632;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1024835;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-7-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:47732;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-7-768x474.png\";s:5:\"width\";i:768;s:6:\"height\";i:474;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:601854;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:18:\"nbs-7-1536x947.png\";s:5:\"width\";i:1536;s:6:\"height\";i:947;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2150055;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:19:\"nbs-7-2048x1263.png\";s:5:\"width\";i:2048;s:6:\"height\";i:1263;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3613801;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:19:\"nbs-7-2560x1579.png\";s:5:\"width\";i:2560;s:6:\"height\";i:1579;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:5534347;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:19:\"nbs-7-1920x1184.png\";s:5:\"width\";i:1920;s:6:\"height\";i:1184;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3256464;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:18:\"nbs-7-1440x888.png\";s:5:\"width\";i:1440;s:6:\"height\";i:888;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1910808;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:18:\"nbs-7-1280x789.png\";s:5:\"width\";i:1280;s:6:\"height\";i:789;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1541822;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:18:\"nbs-7-1024x632.png\";s:5:\"width\";i:1024;s:6:\"height\";i:632;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1024835;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-7-768x474.png\";s:5:\"width\";i:768;s:6:\"height\";i:474;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:601854;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-7-374x231.png\";s:5:\"width\";i:374;s:6:\"height\";i:231;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:167205;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:9:\"nbs-7.png\";}'),
(70,25,'_wp_attached_file','2026/02/nbs-8.png'),
(71,25,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:17:\"2026/02/nbs-8.png\";s:8:\"filesize\";i:486237;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-8-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:25530;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-8-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:155738;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-8-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10296;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-8-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:116409;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-8-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:312804;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-8-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:330267;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-8-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:267398;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-8-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:182031;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-8-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:116409;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-8-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:40884;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(72,26,'_wp_attached_file','2026/02/nbs-9.png'),
(73,26,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:17:\"2026/02/nbs-9.png\";s:8:\"filesize\";i:551743;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"nbs-9-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:27121;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"nbs-9-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:182102;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"nbs-9-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:22965;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"nbs-9-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:134537;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-9-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:363676;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-9-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:383351;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-9-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:307620;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-9-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:487743;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:17:\"nbs-9-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:134537;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:17:\"nbs-9-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:43613;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(74,27,'_wp_attached_file','2026/02/nbs-10.png'),
(75,27,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-10.png\";s:8:\"filesize\";i:828288;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-10-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:40856;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-10-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:326355;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-10-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:38386;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-10-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:250841;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-10-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:640574;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-10-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:699318;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-10-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:579935;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-10-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:386083;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-10-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:250841;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-10-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:72257;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(76,28,'_wp_attached_file','2026/02/nbs-11.png'),
(77,28,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-11.png\";s:8:\"filesize\";i:1008746;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-11-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:49857;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-11-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:605594;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-11-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:14976;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-11-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:400553;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-11-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1346849;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-11-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1438073;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-11-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1144866;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-11-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:738697;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-11-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:400553;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-11-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:92792;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(78,29,'_wp_attached_file','2026/02/nbs-12.png'),
(79,29,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-12.png\";s:8:\"filesize\";i:107116;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-12-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:9099;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-12-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:71559;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-12-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:5777;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-12-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:54329;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-12-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:120733;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-12-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:125438;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-12-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:107854;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-12-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:82019;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-12-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:54329;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-12-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:17900;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(80,30,'_wp_attached_file','2026/02/nbs-13.png'),
(81,30,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-13.png\";s:8:\"filesize\";i:1364104;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-13-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:53486;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-13-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:428015;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-13-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:18111;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-13-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:307396;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-13-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:887787;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-13-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:939945;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-13-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:761724;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-13-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:512073;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-13-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:307396;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-13-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:89739;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(82,31,'_wp_attached_file','2026/02/nbs-14.png'),
(83,31,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-14.png\";s:8:\"filesize\";i:1380865;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-14-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:97608;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-14-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:416880;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-14-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:32932;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-14-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:646732;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-14-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1969811;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-14-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2081071;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-14-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:773026;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-14-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:502024;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-14-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:646732;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-14-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:170930;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(84,32,'_wp_attached_file','2026/02/nbs-15.png'),
(85,32,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-15.png\";s:8:\"filesize\";i:1321406;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-15-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:78305;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-15-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:343093;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-15-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:14996;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-15-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:490875;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-15-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:748646;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-15-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1697610;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-15-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:632589;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-15-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:855271;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-15-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:490875;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-15-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:131184;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(86,33,'_wp_attached_file','2026/02/nbs-16.png'),
(87,33,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-16.png\";s:8:\"filesize\";i:1796334;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-16-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:94137;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-16-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:908148;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-16-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:17382;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-16-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:314900;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-16-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:974586;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-16-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1036091;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-16-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:820876;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-16-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:537118;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-16-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:314900;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-16-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:164417;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(88,34,'_wp_attached_file','2026/02/nbs-17.png'),
(89,34,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1825;s:6:\"height\";i:2009;s:4:\"file\";s:18:\"2026/02/nbs-17.png\";s:8:\"filesize\";i:1586687;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-17-273x300.png\";s:5:\"width\";i:273;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:21338;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-17-930x1024.png\";s:5:\"width\";i:930;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:165929;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-17-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:7729;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-17-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:116852;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"nbs-17-1395x1536.png\";s:5:\"width\";i:1395;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:396892;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:20:\"nbs-17-1440x1585.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1585;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:426313;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:20:\"nbs-17-1280x1409.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1409;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:334090;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:20:\"nbs-17-1024x1127.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:201017;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-17-768x845.png\";s:5:\"width\";i:768;s:6:\"height\";i:845;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:116852;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-17-374x412.png\";s:5:\"width\";i:374;s:6:\"height\";i:412;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:34896;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(90,35,'_wp_attached_file','2026/02/nbs-18-scaled.png'),
(91,35,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1579;s:4:\"file\";s:25:\"2026/02/nbs-18-scaled.png\";s:8:\"filesize\";i:3905958;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"nbs-18-300x185.png\";s:5:\"width\";i:300;s:6:\"height\";i:185;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:80153;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"nbs-18-1024x632.png\";s:5:\"width\";i:1024;s:6:\"height\";i:632;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:767520;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"nbs-18-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:37832;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"nbs-18-768x474.png\";s:5:\"width\";i:768;s:6:\"height\";i:474;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:450777;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"nbs-18-1536x947.png\";s:5:\"width\";i:1536;s:6:\"height\";i:947;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1592961;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:20:\"nbs-18-2048x1263.png\";s:5:\"width\";i:2048;s:6:\"height\";i:1263;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2626953;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:20:\"nbs-18-2560x1579.png\";s:5:\"width\";i:2560;s:6:\"height\";i:1579;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3905958;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:20:\"nbs-18-1920x1184.png\";s:5:\"width\";i:1920;s:6:\"height\";i:1184;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2374924;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:19:\"nbs-18-1440x888.png\";s:5:\"width\";i:1440;s:6:\"height\";i:888;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1418875;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:19:\"nbs-18-1280x789.png\";s:5:\"width\";i:1280;s:6:\"height\";i:789;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1148250;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:19:\"nbs-18-1024x632.png\";s:5:\"width\";i:1024;s:6:\"height\";i:632;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:767520;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:18:\"nbs-18-768x474.png\";s:5:\"width\";i:768;s:6:\"height\";i:474;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:450777;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:18:\"nbs-18-374x231.png\";s:5:\"width\";i:374;s:6:\"height\";i:231;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:119974;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:10:\"nbs-18.png\";}'),
(92,16,'project__galleries_0_project__gallery','a:3:{i:0;s:2:\"18\";i:1;s:2:\"19\";i:2;s:2:\"20\";}'),
(93,16,'_project__galleries_0_project__gallery','field_c85a091d'),
(94,16,'project__galleries','9'),
(95,16,'_project__galleries','field_d1f2eebd'),
(96,36,'_wp_attached_file','2026/02/thumb-nbs-scaled.png'),
(97,36,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:1080;s:4:\"file\";s:28:\"2026/02/thumb-nbs-scaled.png\";s:8:\"filesize\";i:2969615;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:21:\"thumb-nbs-300x127.png\";s:5:\"width\";i:300;s:6:\"height\";i:127;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:61086;}s:5:\"large\";a:5:{s:4:\"file\";s:22:\"thumb-nbs-1024x432.png\";s:5:\"width\";i:1024;s:6:\"height\";i:432;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:560410;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:21:\"thumb-nbs-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:33938;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:21:\"thumb-nbs-768x324.png\";s:5:\"width\";i:768;s:6:\"height\";i:324;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:327815;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:22:\"thumb-nbs-1536x648.png\";s:5:\"width\";i:1536;s:6:\"height\";i:648;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1165805;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:22:\"thumb-nbs-2048x864.png\";s:5:\"width\";i:2048;s:6:\"height\";i:864;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1935227;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:23:\"thumb-nbs-2560x1080.png\";s:5:\"width\";i:2560;s:6:\"height\";i:1080;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2969615;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:22:\"thumb-nbs-1920x810.png\";s:5:\"width\";i:1920;s:6:\"height\";i:810;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1758082;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:22:\"thumb-nbs-1440x608.png\";s:5:\"width\";i:1440;s:6:\"height\";i:608;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1038623;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:22:\"thumb-nbs-1280x540.png\";s:5:\"width\";i:1280;s:6:\"height\";i:540;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:838930;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:22:\"thumb-nbs-1024x432.png\";s:5:\"width\";i:1024;s:6:\"height\";i:432;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:560410;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:21:\"thumb-nbs-768x324.png\";s:5:\"width\";i:768;s:6:\"height\";i:324;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:327815;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:21:\"thumb-nbs-374x158.png\";s:5:\"width\";i:374;s:6:\"height\";i:158;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:90339;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:13:\"thumb-nbs.png\";}'),
(98,16,'_thumbnail_id','36'),
(99,5,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(100,5,'_home__project_front','field_8fd587e3'),
(101,37,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(102,37,'_home__title','field_55a225b4'),
(103,37,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(104,37,'_home__project_front','field_8fd587e3'),
(105,16,'project__year','2025'),
(106,16,'_project__year','field_8efb34f0'),
(107,38,'_wp_attached_file','2026/02/chloe-1.jpg'),
(108,38,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1693;s:6:\"height\";i:1775;s:4:\"file\";s:19:\"2026/02/chloe-1.jpg\";s:8:\"filesize\";i:551960;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:19:\"chloe-1-286x300.jpg\";s:5:\"width\";i:286;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19825;}s:5:\"large\";a:5:{s:4:\"file\";s:20:\"chloe-1-977x1024.jpg\";s:5:\"width\";i:977;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:133562;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:19:\"chloe-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7418;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:19:\"chloe-1-768x805.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:805;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:92048;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:21:\"chloe-1-1465x1536.jpg\";s:5:\"width\";i:1465;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:248950;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:21:\"chloe-1-1440x1510.jpg\";s:5:\"width\";i:1440;s:6:\"height\";i:1510;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:242549;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:21:\"chloe-1-1280x1342.jpg\";s:5:\"width\";i:1280;s:6:\"height\";i:1342;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:201427;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:21:\"chloe-1-1024x1074.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1074;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:143900;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:19:\"chloe-1-768x805.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:805;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:92048;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:19:\"chloe-1-374x392.jpg\";s:5:\"width\";i:374;s:6:\"height\";i:392;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30203;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:6:\"iPhone\";s:7:\"caption\";s:33:\"Processed with VSCO with 2 preset\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:36:\"Copyright 2024. All rights reserved.\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:33:\"Processed with VSCO with 2 preset\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(109,5,'home__first_content_left_title','La Résonance'),
(110,5,'_home__first_content_left_title','field_f4d96bb3'),
(111,5,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(112,5,'_home__first_content_first_text','field_d273fae3'),
(113,5,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste. Et quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(114,5,'_home__first_content_second_text','field_915e4347'),
(115,5,'home__first_content_image','38'),
(116,5,'_home__first_content_image','field_23ac313c'),
(117,39,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(118,39,'_home__title','field_55a225b4'),
(119,39,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(120,39,'_home__project_front','field_8fd587e3'),
(121,39,'home__first_content_left_title','la Résonance'),
(122,39,'_home__first_content_left_title','field_f4d96bb3'),
(123,39,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(124,39,'_home__first_content_first_text','field_d273fae3'),
(125,39,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(126,39,'_home__first_content_second_text','field_915e4347'),
(127,39,'home__first_content_image','38'),
(128,39,'_home__first_content_image','field_23ac313c'),
(129,40,'_edit_last','1'),
(130,40,'_edit_lock','1771970578:1'),
(131,40,'project__year',''),
(132,40,'_project__year','field_8efb34f0'),
(133,40,'project__galleries',''),
(134,40,'_project__galleries','field_d1f2eebd'),
(135,41,'_wp_attached_file','2026/02/thumb-de-saint-gall-scaled.png'),
(136,41,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:2560;s:6:\"height\";i:2006;s:4:\"file\";s:38:\"2026/02/thumb-de-saint-gall-scaled.png\";s:8:\"filesize\";i:7588745;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:31:\"thumb-de-saint-gall-300x235.png\";s:5:\"width\";i:300;s:6:\"height\";i:235;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:80289;}s:5:\"large\";a:5:{s:4:\"file\";s:32:\"thumb-de-saint-gall-1024x802.png\";s:5:\"width\";i:1024;s:6:\"height\";i:802;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1073395;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:31:\"thumb-de-saint-gall-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:29246;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:31:\"thumb-de-saint-gall-768x602.png\";s:5:\"width\";i:768;s:6:\"height\";i:602;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:562300;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:33:\"thumb-de-saint-gall-1536x1203.png\";s:5:\"width\";i:1536;s:6:\"height\";i:1203;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2577776;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:33:\"thumb-de-saint-gall-2048x1605.png\";s:5:\"width\";i:2048;s:6:\"height\";i:1605;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4720165;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:33:\"thumb-de-saint-gall-2560x2006.png\";s:5:\"width\";i:2560;s:6:\"height\";i:2006;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:7588745;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:33:\"thumb-de-saint-gall-1920x1504.png\";s:5:\"width\";i:1920;s:6:\"height\";i:1504;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4161943;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:33:\"thumb-de-saint-gall-1440x1128.png\";s:5:\"width\";i:1440;s:6:\"height\";i:1128;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2243817;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:33:\"thumb-de-saint-gall-1280x1003.png\";s:5:\"width\";i:1280;s:6:\"height\";i:1003;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1742258;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:32:\"thumb-de-saint-gall-1024x802.png\";s:5:\"width\";i:1024;s:6:\"height\";i:802;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1073395;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:31:\"thumb-de-saint-gall-768x602.png\";s:5:\"width\";i:768;s:6:\"height\";i:602;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:562300;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:31:\"thumb-de-saint-gall-374x293.png\";s:5:\"width\";i:374;s:6:\"height\";i:293;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:121759;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:23:\"thumb-de-saint-gall.png\";}'),
(137,40,'_thumbnail_id','41'),
(140,43,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(141,43,'_home__title','field_55a225b4'),
(142,43,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(143,43,'_home__project_front','field_8fd587e3'),
(144,43,'home__first_content_left_title','La Résonance'),
(145,43,'_home__first_content_left_title','field_f4d96bb3'),
(146,43,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(147,43,'_home__first_content_first_text','field_d273fae3'),
(148,43,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(149,43,'_home__first_content_second_text','field_915e4347'),
(150,43,'home__first_content_image','38'),
(151,43,'_home__first_content_image','field_23ac313c'),
(152,44,'_edit_last','1'),
(153,44,'_edit_lock','1771937766:1'),
(154,44,'project__year',''),
(155,44,'_project__year','field_8efb34f0'),
(156,44,'project__galleries',''),
(157,44,'_project__galleries','field_d1f2eebd'),
(158,45,'_wp_attached_file','2026/02/thumb-mamie-boulangerie-scaled.jpg'),
(159,45,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:2367;s:6:\"height\";i:2560;s:4:\"file\";s:42:\"2026/02/thumb-mamie-boulangerie-scaled.jpg\";s:8:\"filesize\";i:412247;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:35:\"thumb-mamie-boulangerie-277x300.jpg\";s:5:\"width\";i:277;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17291;}s:5:\"large\";a:5:{s:4:\"file\";s:36:\"thumb-mamie-boulangerie-947x1024.jpg\";s:5:\"width\";i:947;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:112493;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:35:\"thumb-mamie-boulangerie-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7023;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:35:\"thumb-mamie-boulangerie-768x831.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:831;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:82421;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:37:\"thumb-mamie-boulangerie-1420x1536.jpg\";s:5:\"width\";i:1420;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:201821;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:37:\"thumb-mamie-boulangerie-1894x2048.jpg\";s:5:\"width\";i:1894;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:300818;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:37:\"thumb-mamie-boulangerie-2560x2769.jpg\";s:5:\"width\";i:2560;s:6:\"height\";i:2769;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:455678;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:37:\"thumb-mamie-boulangerie-1920x2077.jpg\";s:5:\"width\";i:1920;s:6:\"height\";i:2077;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:307724;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:37:\"thumb-mamie-boulangerie-1440x1557.jpg\";s:5:\"width\";i:1440;s:6:\"height\";i:1557;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:204447;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:37:\"thumb-mamie-boulangerie-1280x1384.jpg\";s:5:\"width\";i:1280;s:6:\"height\";i:1384;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:173062;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:37:\"thumb-mamie-boulangerie-1024x1108.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1108;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:125669;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:35:\"thumb-mamie-boulangerie-768x831.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:831;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:82421;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:35:\"thumb-mamie-boulangerie-374x405.jpg\";s:5:\"width\";i:374;s:6:\"height\";i:405;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27152;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:27:\"thumb-mamie-boulangerie.jpg\";}'),
(160,44,'_thumbnail_id','45'),
(161,5,'home__where_begin_title','Là où ça commence'),
(162,5,'_home__where_begin_title','field_7dbcb7de'),
(163,5,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(164,5,'_home__where_begin','field_95502037'),
(165,46,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(166,46,'_home__title','field_55a225b4'),
(167,46,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(168,46,'_home__project_front','field_8fd587e3'),
(169,46,'home__first_content_left_title','La Résonance'),
(170,46,'_home__first_content_left_title','field_f4d96bb3'),
(171,46,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(172,46,'_home__first_content_first_text','field_d273fae3'),
(173,46,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(174,46,'_home__first_content_second_text','field_915e4347'),
(175,46,'home__first_content_image','38'),
(176,46,'_home__first_content_image','field_23ac313c'),
(177,46,'home__where_begin_title','Là où ça commence'),
(178,46,'_home__where_begin_title','field_7dbcb7de'),
(179,46,'home__where_begin',''),
(180,46,'_home__where_begin','field_95502037'),
(181,47,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(182,47,'_home__title','field_55a225b4'),
(183,47,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(184,47,'_home__project_front','field_8fd587e3'),
(185,47,'home__first_content_left_title','La Résonance'),
(186,47,'_home__first_content_left_title','field_f4d96bb3'),
(187,47,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(188,47,'_home__first_content_first_text','field_d273fae3'),
(189,47,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(190,47,'_home__first_content_second_text','field_915e4347'),
(191,47,'home__first_content_image','38'),
(192,47,'_home__first_content_image','field_23ac313c'),
(193,47,'home__where_begin_title','Là où ça commence'),
(194,47,'_home__where_begin_title','field_7dbcb7de'),
(195,47,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(196,47,'_home__where_begin','field_95502037'),
(197,48,'_wp_attached_file','2026/02/image-begin-scaled.jpg'),
(198,48,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:1707;s:6:\"height\";i:2560;s:4:\"file\";s:30:\"2026/02/image-begin-scaled.jpg\";s:8:\"filesize\";i:530104;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"image-begin-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16331;}s:5:\"large\";a:5:{s:4:\"file\";s:24:\"image-begin-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:114392;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"image-begin-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7477;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:24:\"image-begin-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:137391;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:25:\"image-begin-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:219037;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:25:\"image-begin-1366x2048.jpg\";s:5:\"width\";i:1366;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:355652;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:25:\"image-begin-2560x3840.jpg\";s:5:\"width\";i:2560;s:6:\"height\";i:3840;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1129296;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:25:\"image-begin-1920x2880.jpg\";s:5:\"width\";i:1920;s:6:\"height\";i:2880;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:656073;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:25:\"image-begin-1440x2160.jpg\";s:5:\"width\";i:1440;s:6:\"height\";i:2160;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:391027;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:25:\"image-begin-1280x1920.jpg\";s:5:\"width\";i:1280;s:6:\"height\";i:1920;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:319050;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:25:\"image-begin-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:219037;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:24:\"image-begin-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:137391;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:23:\"image-begin-374x561.jpg\";s:5:\"width\";i:374;s:6:\"height\";i:561;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:44029;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:15:\"image-begin.jpg\";}'),
(199,5,'home__where_begin_image_1','48'),
(200,5,'_home__where_begin_image_1','field_884d756d'),
(201,5,'home__where_begin_image_2','48'),
(202,5,'_home__where_begin_image_2','field_854d70b4'),
(203,5,'home__where_begin_image_3','48'),
(204,5,'_home__where_begin_image_3','field_864d7247'),
(205,5,'home__where_begin_image_4','48'),
(206,5,'_home__where_begin_image_4','field_834d6d8e'),
(207,5,'home__where_begin_image_5','48'),
(208,5,'_home__where_begin_image_5','field_844d6f21'),
(209,5,'home__where_begin_image_6','48'),
(210,5,'_home__where_begin_image_6','field_814d6a68'),
(211,49,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(212,49,'_home__title','field_55a225b4'),
(213,49,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(214,49,'_home__project_front','field_8fd587e3'),
(215,49,'home__first_content_left_title','La Résonance'),
(216,49,'_home__first_content_left_title','field_f4d96bb3'),
(217,49,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(218,49,'_home__first_content_first_text','field_d273fae3'),
(219,49,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(220,49,'_home__first_content_second_text','field_915e4347'),
(221,49,'home__first_content_image','38'),
(222,49,'_home__first_content_image','field_23ac313c'),
(223,49,'home__where_begin_title','Là où ça commence'),
(224,49,'_home__where_begin_title','field_7dbcb7de'),
(225,49,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(226,49,'_home__where_begin','field_95502037'),
(227,49,'home__where_begin_image_1','48'),
(228,49,'_home__where_begin_image_1','field_884d756d'),
(229,49,'home__where_begin_image_2','48'),
(230,49,'_home__where_begin_image_2','field_854d70b4'),
(231,49,'home__where_begin_image_3','48'),
(232,49,'_home__where_begin_image_3','field_864d7247'),
(233,49,'home__where_begin_image_4','48'),
(234,49,'_home__where_begin_image_4','field_834d6d8e'),
(235,49,'home__where_begin_image_5','48'),
(236,49,'_home__where_begin_image_5','field_844d6f21'),
(237,49,'home__where_begin_image_6','48'),
(238,49,'_home__where_begin_image_6','field_814d6a68'),
(239,5,'home__about_image','50'),
(240,5,'_home__about_image','field_8ae6cab9'),
(241,5,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(242,5,'_home__about_text_blue','field_af641c20'),
(243,5,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(244,5,'_home__about_text_iam','field_d1bde9b5'),
(245,5,'home__about_first_text','Née en Normandie, j’ai grandi dans une famille où l’art était présent à chaque moment. Petite, j’ai exploré plusieurs pratiques : la poterie, les arts plastiques, la musique, la danse… Après un parcours scolaire classique, <strong>je me suis naturellement dirigée vers la communication et le design</strong>.'),
(246,5,'_home__about_first_text','field_ac7f3650'),
(247,5,'home__about_second_text','J’ai commencé par une MANAA à YNOV Campus - Nantes, puis un BTS Communication. C’est là que <strong>mon amour pour le design graphique</strong> est né, grâce à des stages d’études. J’ai ensuite poursuivi avec <strong>une licence en design graphique</strong> à LISAA Nantes, avant de partir à Marseille pour un <strong>master en direction artistique</strong>, en alternance dans une agence de digital marketing. À la fin de mes études, je suis partie à Metz pour intégrer une agence de communication.'),
(248,5,'_home__about_second_text','field_d2067f2e'),
(249,50,'_wp_attached_file','2026/02/chloe-2-scaled.jpg'),
(250,50,'_wp_attachment_metadata','a:7:{s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:4:\"file\";s:26:\"2026/02/chloe-2-scaled.jpg\";s:8:\"filesize\";i:931832;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:19:\"chloe-2-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:39970;}s:5:\"large\";a:5:{s:4:\"file\";s:20:\"chloe-2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:174752;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:19:\"chloe-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30273;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:20:\"chloe-2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:174752;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:21:\"chloe-2-1152x1536.jpg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:351087;}s:9:\"2048x2048\";a:5:{s:4:\"file\";s:21:\"chloe-2-1536x2048.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:603977;}s:11:\"custom-2560\";a:5:{s:4:\"file\";s:21:\"chloe-2-2560x3413.jpg\";s:5:\"width\";i:2560;s:6:\"height\";i:3413;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1622207;}s:11:\"custom-1920\";a:5:{s:4:\"file\";s:21:\"chloe-2-1920x2560.jpg\";s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:931832;}s:11:\"custom-1440\";a:5:{s:4:\"file\";s:21:\"chloe-2-1440x1920.jpg\";s:5:\"width\";i:1440;s:6:\"height\";i:1920;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:532852;}s:11:\"custom-1280\";a:5:{s:4:\"file\";s:21:\"chloe-2-1280x1707.jpg\";s:5:\"width\";i:1280;s:6:\"height\";i:1707;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:428041;}s:11:\"custom-1024\";a:5:{s:4:\"file\";s:21:\"chloe-2-1024x1365.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1365;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:284688;}s:10:\"custom-768\";a:5:{s:4:\"file\";s:20:\"chloe-2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:174752;}s:10:\"custom-374\";a:5:{s:4:\"file\";s:19:\"chloe-2-374x499.jpg\";s:5:\"width\";i:374;s:6:\"height\";i:499;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:63791;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.9\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:9:\"iPhone 15\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1763040472\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"2.69\";s:3:\"iso\";s:2:\"64\";s:13:\"shutter_speed\";s:4:\"0.02\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:11:\"chloe-2.jpg\";}'),
(251,51,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(252,51,'_home__title','field_55a225b4'),
(253,51,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(254,51,'_home__project_front','field_8fd587e3'),
(255,51,'home__first_content_left_title','La Résonance'),
(256,51,'_home__first_content_left_title','field_f4d96bb3'),
(257,51,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(258,51,'_home__first_content_first_text','field_d273fae3'),
(259,51,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(260,51,'_home__first_content_second_text','field_915e4347'),
(261,51,'home__first_content_image','38'),
(262,51,'_home__first_content_image','field_23ac313c'),
(263,51,'home__where_begin_title','Là où ça commence'),
(264,51,'_home__where_begin_title','field_7dbcb7de'),
(265,51,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(266,51,'_home__where_begin','field_95502037'),
(267,51,'home__where_begin_image_1','48'),
(268,51,'_home__where_begin_image_1','field_884d756d'),
(269,51,'home__where_begin_image_2','48'),
(270,51,'_home__where_begin_image_2','field_854d70b4'),
(271,51,'home__where_begin_image_3','48'),
(272,51,'_home__where_begin_image_3','field_864d7247'),
(273,51,'home__where_begin_image_4','48'),
(274,51,'_home__where_begin_image_4','field_834d6d8e'),
(275,51,'home__where_begin_image_5','48'),
(276,51,'_home__where_begin_image_5','field_844d6f21'),
(277,51,'home__where_begin_image_6','48'),
(278,51,'_home__where_begin_image_6','field_814d6a68'),
(279,51,'home__about_image','50'),
(280,51,'_home__about_image','field_8ae6cab9'),
(281,51,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(282,51,'_home__about_text_blue','field_af641c20'),
(283,51,'home__about_text_iam','je suis Chloé'),
(284,51,'_home__about_text_iam','field_d1bde9b5'),
(285,51,'home__about_first_text',''),
(286,51,'_home__about_first_text','field_ac7f3650'),
(287,51,'home__about_second_text',''),
(288,51,'_home__about_second_text','field_d2067f2e'),
(289,52,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(290,52,'_home__title','field_55a225b4'),
(291,52,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(292,52,'_home__project_front','field_8fd587e3'),
(293,52,'home__first_content_left_title','La Résonance'),
(294,52,'_home__first_content_left_title','field_f4d96bb3'),
(295,52,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(296,52,'_home__first_content_first_text','field_d273fae3'),
(297,52,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(298,52,'_home__first_content_second_text','field_915e4347'),
(299,52,'home__first_content_image','38'),
(300,52,'_home__first_content_image','field_23ac313c'),
(301,52,'home__where_begin_title','Là où ça commence'),
(302,52,'_home__where_begin_title','field_7dbcb7de'),
(303,52,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(304,52,'_home__where_begin','field_95502037'),
(305,52,'home__where_begin_image_1','48'),
(306,52,'_home__where_begin_image_1','field_884d756d'),
(307,52,'home__where_begin_image_2','48'),
(308,52,'_home__where_begin_image_2','field_854d70b4'),
(309,52,'home__where_begin_image_3','48'),
(310,52,'_home__where_begin_image_3','field_864d7247'),
(311,52,'home__where_begin_image_4','48'),
(312,52,'_home__where_begin_image_4','field_834d6d8e'),
(313,52,'home__where_begin_image_5','48'),
(314,52,'_home__where_begin_image_5','field_844d6f21'),
(315,52,'home__where_begin_image_6','48'),
(316,52,'_home__where_begin_image_6','field_814d6a68'),
(317,52,'home__about_image','50'),
(318,52,'_home__about_image','field_8ae6cab9'),
(319,52,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(320,52,'_home__about_text_blue','field_af641c20'),
(321,52,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(322,52,'_home__about_text_iam','field_d1bde9b5'),
(323,52,'home__about_first_text',''),
(324,52,'_home__about_first_text','field_ac7f3650'),
(325,52,'home__about_second_text',''),
(326,52,'_home__about_second_text','field_d2067f2e'),
(327,53,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(328,53,'_home__title','field_55a225b4'),
(329,53,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(330,53,'_home__project_front','field_8fd587e3'),
(331,53,'home__first_content_left_title','La Résonance'),
(332,53,'_home__first_content_left_title','field_f4d96bb3'),
(333,53,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(334,53,'_home__first_content_first_text','field_d273fae3'),
(335,53,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(336,53,'_home__first_content_second_text','field_915e4347'),
(337,53,'home__first_content_image','38'),
(338,53,'_home__first_content_image','field_23ac313c'),
(339,53,'home__where_begin_title','Là où ça commence'),
(340,53,'_home__where_begin_title','field_7dbcb7de'),
(341,53,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(342,53,'_home__where_begin','field_95502037'),
(343,53,'home__where_begin_image_1','48'),
(344,53,'_home__where_begin_image_1','field_884d756d'),
(345,53,'home__where_begin_image_2','48'),
(346,53,'_home__where_begin_image_2','field_854d70b4'),
(347,53,'home__where_begin_image_3','48'),
(348,53,'_home__where_begin_image_3','field_864d7247'),
(349,53,'home__where_begin_image_4','48'),
(350,53,'_home__where_begin_image_4','field_834d6d8e'),
(351,53,'home__where_begin_image_5','48'),
(352,53,'_home__where_begin_image_5','field_844d6f21'),
(353,53,'home__where_begin_image_6','48'),
(354,53,'_home__where_begin_image_6','field_814d6a68'),
(355,53,'home__about_image','50'),
(356,53,'_home__about_image','field_8ae6cab9'),
(357,53,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(358,53,'_home__about_text_blue','field_af641c20'),
(359,53,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(360,53,'_home__about_text_iam','field_d1bde9b5'),
(361,53,'home__about_first_text','Née en Normandie, j’ai grandi dans une famille où l’art était présent à chaque moment. Petite, j’ai exploré plusieurs pratiques : la poterie, les arts plastiques, la musique, la danse… Après un parcours scolaire classique, je me suis naturellement dirigée vers la communication et le design.'),
(362,53,'_home__about_first_text','field_ac7f3650'),
(363,53,'home__about_second_text','J’ai commencé par une MANAA à YNOV Campus - Nantes, puis un BTS Communication. C’est là que mon amour pour le design graphique est né, grâce à des stages d’études. J’ai ensuite poursuivi avec une licence en design graphique à LISAA Nantes, avant de partir à Marseille pour un master en direction artistique, en alternance dans une agence de digital marketing. À la fin de mes études, je suis partie à Metz pour intégrer une agence de communication.'),
(364,53,'_home__about_second_text','field_d2067f2e'),
(365,54,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(366,54,'_home__title','field_55a225b4'),
(367,54,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(368,54,'_home__project_front','field_8fd587e3'),
(369,54,'home__first_content_left_title','La Résonance'),
(370,54,'_home__first_content_left_title','field_f4d96bb3'),
(371,54,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(372,54,'_home__first_content_first_text','field_d273fae3'),
(373,54,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(374,54,'_home__first_content_second_text','field_915e4347'),
(375,54,'home__first_content_image','38'),
(376,54,'_home__first_content_image','field_23ac313c'),
(377,54,'home__where_begin_title','Là où ça commence'),
(378,54,'_home__where_begin_title','field_7dbcb7de'),
(379,54,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(380,54,'_home__where_begin','field_95502037'),
(381,54,'home__where_begin_image_1','48'),
(382,54,'_home__where_begin_image_1','field_884d756d'),
(383,54,'home__where_begin_image_2','48'),
(384,54,'_home__where_begin_image_2','field_854d70b4'),
(385,54,'home__where_begin_image_3','48'),
(386,54,'_home__where_begin_image_3','field_864d7247'),
(387,54,'home__where_begin_image_4','48'),
(388,54,'_home__where_begin_image_4','field_834d6d8e'),
(389,54,'home__where_begin_image_5','48'),
(390,54,'_home__where_begin_image_5','field_844d6f21'),
(391,54,'home__where_begin_image_6','48'),
(392,54,'_home__where_begin_image_6','field_814d6a68'),
(393,54,'home__about_image','50'),
(394,54,'_home__about_image','field_8ae6cab9'),
(395,54,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(396,54,'_home__about_text_blue','field_af641c20'),
(397,54,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(398,54,'_home__about_text_iam','field_d1bde9b5'),
(399,54,'home__about_first_text','Née en Normandie, j’ai grandi dans une famille où l’art était présent à chaque moment. Petite, j’ai exploré plusieurs pratiques : la poterie, les arts plastiques, la musique, la danse… Après un parcours scolaire classique, <strong>je me suis naturellement dirigée vers la communication et le design</strong>.'),
(400,54,'_home__about_first_text','field_ac7f3650'),
(401,54,'home__about_second_text','J’ai commencé par une MANAA à YNOV Campus - Nantes, puis un BTS Communication. C’est là que mon amour pour le design graphique est né, grâce à des stages d’études. J’ai ensuite poursuivi avec une licence en design graphique à LISAA Nantes, avant de partir à Marseille pour un master en direction artistique, en alternance dans une agence de digital marketing. À la fin de mes études, je suis partie à Metz pour intégrer une agence de communication.'),
(402,54,'_home__about_second_text','field_d2067f2e'),
(403,55,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(404,55,'_home__title','field_55a225b4'),
(405,55,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(406,55,'_home__project_front','field_8fd587e3'),
(407,55,'home__first_content_left_title','La Résonance'),
(408,55,'_home__first_content_left_title','field_f4d96bb3'),
(409,55,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(410,55,'_home__first_content_first_text','field_d273fae3'),
(411,55,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(412,55,'_home__first_content_second_text','field_915e4347'),
(413,55,'home__first_content_image','38'),
(414,55,'_home__first_content_image','field_23ac313c'),
(415,55,'home__where_begin_title','Là où ça commence'),
(416,55,'_home__where_begin_title','field_7dbcb7de'),
(417,55,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(418,55,'_home__where_begin','field_95502037'),
(419,55,'home__where_begin_image_1','48'),
(420,55,'_home__where_begin_image_1','field_884d756d'),
(421,55,'home__where_begin_image_2','48'),
(422,55,'_home__where_begin_image_2','field_854d70b4'),
(423,55,'home__where_begin_image_3','48'),
(424,55,'_home__where_begin_image_3','field_864d7247'),
(425,55,'home__where_begin_image_4','48'),
(426,55,'_home__where_begin_image_4','field_834d6d8e'),
(427,55,'home__where_begin_image_5','48'),
(428,55,'_home__where_begin_image_5','field_844d6f21'),
(429,55,'home__where_begin_image_6','48'),
(430,55,'_home__where_begin_image_6','field_814d6a68'),
(431,55,'home__about_image','50'),
(432,55,'_home__about_image','field_8ae6cab9'),
(433,55,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(434,55,'_home__about_text_blue','field_af641c20'),
(435,55,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(436,55,'_home__about_text_iam','field_d1bde9b5'),
(437,55,'home__about_first_text','Née en Normandie, j’ai grandi dans une famille où l’art était présent à chaque moment. Petite, j’ai exploré plusieurs pratiques : la poterie, les arts plastiques, la musique, la danse… Après un parcours scolaire classique, <strong>je me suis naturellement dirigée vers la communication et le design</strong>.'),
(438,55,'_home__about_first_text','field_ac7f3650'),
(439,55,'home__about_second_text','J’ai commencé par une MANAA à YNOV Campus - Nantes, puis un BTS Communication. C’est là que <strong>mon amour pour le design graphique</strong> est né, grâce à des stages d’études. J’ai ensuite poursuivi avec <strong>une licence en design graphique</strong> à LISAA Nantes, avant de partir à Marseille pour un <strong>master en direction artistique</strong>, en alternance dans une agence de digital marketing. À la fin de mes études, je suis partie à Metz pour intégrer une agence de communication.'),
(440,55,'_home__about_second_text','field_d2067f2e'),
(441,16,'project__hero_homepage_image','32'),
(442,16,'_project__hero_homepage_image','field_a3b4c31c'),
(443,16,'project__hero_homepage_title','Business School'),
(444,16,'_project__hero_homepage_title','field_b17c8e0f'),
(445,56,'home__title','construire du <strong>Sens</strong>, <br class=\"lg:hidden\"> faire naître du <strong>Désir</strong>'),
(446,56,'_home__title','field_55a225b4'),
(447,56,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(448,56,'_home__project_front','field_8fd587e3'),
(449,56,'home__first_content_left_title','La Résonance'),
(450,56,'_home__first_content_left_title','field_f4d96bb3'),
(451,56,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(452,56,'_home__first_content_first_text','field_d273fae3'),
(453,56,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(454,56,'_home__first_content_second_text','field_915e4347'),
(455,56,'home__first_content_image','38'),
(456,56,'_home__first_content_image','field_23ac313c'),
(457,56,'home__where_begin_title','Là où ça commence'),
(458,56,'_home__where_begin_title','field_7dbcb7de'),
(459,56,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(460,56,'_home__where_begin','field_95502037'),
(461,56,'home__where_begin_image_1','48'),
(462,56,'_home__where_begin_image_1','field_884d756d'),
(463,56,'home__where_begin_image_2','48'),
(464,56,'_home__where_begin_image_2','field_854d70b4'),
(465,56,'home__where_begin_image_3','48'),
(466,56,'_home__where_begin_image_3','field_864d7247'),
(467,56,'home__where_begin_image_4','48'),
(468,56,'_home__where_begin_image_4','field_834d6d8e'),
(469,56,'home__where_begin_image_5','48'),
(470,56,'_home__where_begin_image_5','field_844d6f21'),
(471,56,'home__where_begin_image_6','48'),
(472,56,'_home__where_begin_image_6','field_814d6a68'),
(473,56,'home__about_image','50'),
(474,56,'_home__about_image','field_8ae6cab9'),
(475,56,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(476,56,'_home__about_text_blue','field_af641c20'),
(477,56,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(478,56,'_home__about_text_iam','field_d1bde9b5'),
(479,56,'home__about_first_text','Née en Normandie, j’ai grandi dans une famille où l’art était présent à chaque moment. Petite, j’ai exploré plusieurs pratiques : la poterie, les arts plastiques, la musique, la danse… Après un parcours scolaire classique, <strong>je me suis naturellement dirigée vers la communication et le design</strong>.'),
(480,56,'_home__about_first_text','field_ac7f3650'),
(481,56,'home__about_second_text','J’ai commencé par une MANAA à YNOV Campus - Nantes, puis un BTS Communication. C’est là que <strong>mon amour pour le design graphique</strong> est né, grâce à des stages d’études. J’ai ensuite poursuivi avec <strong>une licence en design graphique</strong> à LISAA Nantes, avant de partir à Marseille pour un <strong>master en direction artistique</strong>, en alternance dans une agence de digital marketing. À la fin de mes études, je suis partie à Metz pour intégrer une agence de communication.'),
(482,56,'_home__about_second_text','field_d2067f2e'),
(483,57,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(484,57,'_home__title','field_55a225b4'),
(485,57,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(486,57,'_home__project_front','field_8fd587e3'),
(487,57,'home__first_content_left_title','La Résonance'),
(488,57,'_home__first_content_left_title','field_f4d96bb3'),
(489,57,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(490,57,'_home__first_content_first_text','field_d273fae3'),
(491,57,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(492,57,'_home__first_content_second_text','field_915e4347'),
(493,57,'home__first_content_image','38'),
(494,57,'_home__first_content_image','field_23ac313c'),
(495,57,'home__where_begin_title','Là où ça commence'),
(496,57,'_home__where_begin_title','field_7dbcb7de'),
(497,57,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(498,57,'_home__where_begin','field_95502037'),
(499,57,'home__where_begin_image_1','48'),
(500,57,'_home__where_begin_image_1','field_884d756d'),
(501,57,'home__where_begin_image_2','48'),
(502,57,'_home__where_begin_image_2','field_854d70b4'),
(503,57,'home__where_begin_image_3','48'),
(504,57,'_home__where_begin_image_3','field_864d7247'),
(505,57,'home__where_begin_image_4','48'),
(506,57,'_home__where_begin_image_4','field_834d6d8e'),
(507,57,'home__where_begin_image_5','48'),
(508,57,'_home__where_begin_image_5','field_844d6f21'),
(509,57,'home__where_begin_image_6','48'),
(510,57,'_home__where_begin_image_6','field_814d6a68'),
(511,57,'home__about_image','50'),
(512,57,'_home__about_image','field_8ae6cab9'),
(513,57,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(514,57,'_home__about_text_blue','field_af641c20'),
(515,57,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(516,57,'_home__about_text_iam','field_d1bde9b5'),
(517,57,'home__about_first_text','Née en Normandie, j’ai grandi dans une famille où l’art était présent à chaque moment. Petite, j’ai exploré plusieurs pratiques : la poterie, les arts plastiques, la musique, la danse… Après un parcours scolaire classique, <strong>je me suis naturellement dirigée vers la communication et le design</strong>.'),
(518,57,'_home__about_first_text','field_ac7f3650'),
(519,57,'home__about_second_text','J’ai commencé par une MANAA à YNOV Campus - Nantes, puis un BTS Communication. C’est là que <strong>mon amour pour le design graphique</strong> est né, grâce à des stages d’études. J’ai ensuite poursuivi avec <strong>une licence en design graphique</strong> à LISAA Nantes, avant de partir à Marseille pour un <strong>master en direction artistique</strong>, en alternance dans une agence de digital marketing. À la fin de mes études, je suis partie à Metz pour intégrer une agence de communication.'),
(520,57,'_home__about_second_text','field_d2067f2e'),
(521,58,'home__title','construire du <strong>Sens</strong>, faire naître du <strong>Désir</strong>'),
(522,58,'_home__title','field_55a225b4'),
(523,58,'home__project_front','a:1:{i:0;s:2:\"16\";}'),
(524,58,'_home__project_front','field_8fd587e3'),
(525,58,'home__first_content_left_title','La Résonance'),
(526,58,'_home__first_content_left_title','field_f4d96bb3'),
(527,58,'home__first_content_first_text','J’ai choisi la <strong>Direction Artistique</strong> parce que créer me tient debout. C’est ma façon de me trouver, d’aller chercher en moi, de mettre en forme l’invisible.'),
(528,58,'_home__first_content_first_text','field_d273fae3'),
(529,58,'home__first_content_second_text','Je cherche du sens, une émotion juste, une image qui reste. Et quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.'),
(530,58,'_home__first_content_second_text','field_915e4347'),
(531,58,'home__first_content_image','38'),
(532,58,'_home__first_content_image','field_23ac313c'),
(533,58,'home__where_begin_title','Là où ça commence'),
(534,58,'_home__where_begin_title','field_7dbcb7de'),
(535,58,'home__where_begin','<strong>Ce qui compte au quotidien, c\'est la qualité des échanges. Les idées se construisent à plusieurs, les discussions affinent, et les frictions utiles. </strong>\r\nL’inspiration vient du monde qui nous entoure, des détails, des rencontres, des choses simples qui déclenchent une direction.'),
(536,58,'_home__where_begin','field_95502037'),
(537,58,'home__where_begin_image_1','48'),
(538,58,'_home__where_begin_image_1','field_884d756d'),
(539,58,'home__where_begin_image_2','48'),
(540,58,'_home__where_begin_image_2','field_854d70b4'),
(541,58,'home__where_begin_image_3','48'),
(542,58,'_home__where_begin_image_3','field_864d7247'),
(543,58,'home__where_begin_image_4','48'),
(544,58,'_home__where_begin_image_4','field_834d6d8e'),
(545,58,'home__where_begin_image_5','48'),
(546,58,'_home__where_begin_image_5','field_844d6f21'),
(547,58,'home__where_begin_image_6','48'),
(548,58,'_home__where_begin_image_6','field_814d6a68'),
(549,58,'home__about_image','50'),
(550,58,'_home__about_image','field_8ae6cab9'),
(551,58,'home__about_text_blue','mon parcours, mon amour pour mon métier.'),
(552,58,'_home__about_text_blue','field_af641c20'),
(553,58,'home__about_text_iam','je suis <strong>Chloé</strong>'),
(554,58,'_home__about_text_iam','field_d1bde9b5'),
(555,58,'home__about_first_text','Née en Normandie, j’ai grandi dans une famille où l’art était présent à chaque moment. Petite, j’ai exploré plusieurs pratiques : la poterie, les arts plastiques, la musique, la danse… Après un parcours scolaire classique, <strong>je me suis naturellement dirigée vers la communication et le design</strong>.'),
(556,58,'_home__about_first_text','field_ac7f3650'),
(557,58,'home__about_second_text','J’ai commencé par une MANAA à YNOV Campus - Nantes, puis un BTS Communication. C’est là que <strong>mon amour pour le design graphique</strong> est né, grâce à des stages d’études. J’ai ensuite poursuivi avec <strong>une licence en design graphique</strong> à LISAA Nantes, avant de partir à Marseille pour un <strong>master en direction artistique</strong>, en alternance dans une agence de digital marketing. À la fin de mes études, je suis partie à Metz pour intégrer une agence de communication.'),
(558,58,'_home__about_second_text','field_d2067f2e'),
(559,10,'_wp_old_date','2026-02-15'),
(560,11,'_wp_old_date','2026-02-15'),
(561,16,'project__galleries_1_project__gallery','a:1:{i:0;s:2:\"21\";}'),
(562,16,'_project__galleries_1_project__gallery','field_c85a091d'),
(563,16,'project__galleries_2_project__gallery','a:2:{i:0;s:2:\"22\";i:1;s:2:\"23\";}'),
(564,16,'_project__galleries_2_project__gallery','field_c85a091d'),
(565,16,'project__galleries_3_project__gallery','a:1:{i:0;s:2:\"24\";}'),
(566,16,'_project__galleries_3_project__gallery','field_c85a091d'),
(567,16,'project__galleries_4_project__gallery','a:3:{i:0;s:2:\"25\";i:1;s:2:\"26\";i:2;s:2:\"27\";}'),
(568,16,'_project__galleries_4_project__gallery','field_c85a091d'),
(569,16,'project__galleries_5_project__gallery','a:2:{i:0;s:2:\"28\";i:1;s:2:\"29\";}'),
(570,16,'_project__galleries_5_project__gallery','field_c85a091d'),
(571,16,'project__galleries_6_project__gallery','a:3:{i:0;s:2:\"30\";i:1;s:2:\"31\";i:2;s:2:\"32\";}'),
(572,16,'_project__galleries_6_project__gallery','field_c85a091d'),
(573,16,'project__galleries_7_project__gallery','a:2:{i:0;s:2:\"33\";i:1;s:2:\"34\";}'),
(574,16,'_project__galleries_7_project__gallery','field_c85a091d'),
(575,16,'project__galleries_8_project__gallery','a:1:{i:0;s:2:\"35\";}'),
(576,16,'_project__galleries_8_project__gallery','field_c85a091d');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `type_status_author` (`post_type`,`post_status`,`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES
(1,1,'2026-02-15 17:41:30','2026-02-15 17:41:30','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','publish','open','open','','hello-world','','','2026-02-15 17:41:30','2026-02-15 17:41:30','',0,'https://chloecrase.ddev.site/?p=1',0,'post','',1),
(2,1,'2026-02-15 17:41:30','2026-02-15 17:41:30','<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">\n<!-- wp:paragraph -->\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p>\n<!-- /wp:paragraph -->\n</blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">\n<!-- wp:paragraph -->\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\n<!-- /wp:paragraph -->\n</blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"https://chloecrase.ddev.site/wp/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->','Sample Page','','publish','closed','open','','sample-page','','','2026-02-15 17:41:30','2026-02-15 17:41:30','',0,'https://chloecrase.ddev.site/?page_id=2',0,'page','',0),
(3,1,'2026-02-15 17:41:30','2026-02-15 17:41:30','<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: https://chloecrase.ddev.site.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n','Privacy Policy','','draft','closed','open','','privacy-policy','','','2026-02-15 17:41:30','2026-02-15 17:41:30','',0,'https://chloecrase.ddev.site/?page_id=3',0,'page','',0),
(5,1,'2026-02-15 17:52:41','2026-02-15 17:52:41','','Accueil','','publish','closed','closed','','accueil','','','2026-02-25 22:26:16','2026-02-25 22:26:16','',0,'https://chloecrase.ddev.site/?page_id=5',0,'page','',0),
(6,1,'2026-02-15 17:52:28','2026-02-15 17:52:28','{\"version\": 3, \"isGlobalStylesUserThemeJSON\": true }','Custom Styles','','publish','closed','closed','','wp-global-styles-sage','','','2026-02-15 17:52:28','2026-02-15 17:52:28','',0,'https://chloecrase.ddev.site/?p=6',0,'wp_global_styles','',0),
(7,1,'2026-02-15 17:52:41','2026-02-15 17:52:41','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-15 17:52:41','2026-02-15 17:52:41','',5,'https://chloecrase.ddev.site/?p=7',0,'revision','',0),
(10,1,'2026-02-26 19:34:37','2026-02-15 19:24:55','','Projets','','publish','closed','closed','','projets','','','2026-02-26 19:34:37','2026-02-26 19:34:37','',0,'https://chloecrase.ddev.site/?p=10',1,'nav_menu_item','',0),
(11,1,'2026-02-26 19:34:37','2026-02-15 19:24:55','','À propos','','publish','closed','closed','','a-propos','','','2026-02-26 19:34:37','2026-02-26 19:34:37','',0,'https://chloecrase.ddev.site/?p=11',2,'nav_menu_item','',0),
(12,1,'2026-02-15 20:04:14','2026-02-15 20:04:14','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-15 20:04:14','2026-02-15 20:04:14','',5,'https://chloecrase.ddev.site/?p=12',0,'revision','',0),
(13,1,'2026-02-15 20:08:22','2026-02-15 20:08:22','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-15 20:08:22','2026-02-15 20:08:22','',5,'https://chloecrase.ddev.site/?p=13',0,'revision','',0),
(14,1,'2026-02-15 20:12:15','2026-02-15 20:12:15','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-15 20:12:15','2026-02-15 20:12:15','',5,'https://chloecrase.ddev.site/?p=14',0,'revision','',0),
(15,1,'2026-02-15 20:12:37','2026-02-15 20:12:37','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-15 20:12:37','2026-02-15 20:12:37','',5,'https://chloecrase.ddev.site/?p=15',0,'revision','',0),
(16,1,'2026-02-15 20:32:50','2026-02-15 20:32:50','Quapropter a natura mihi videtur potius quam ab indigentia orta amicitia, applicatione magis animi cum quodam sensu amandi quam cogitatione quantum illa res utilitatis esset habitura. Quod quidem quale sit, etiam in bestiis quibusdam animadverti potest, quae ex se natos ita amant ad quoddam tempus et ab eis ita amantur ut facile earum sensus appareat. Quod in homine multo est evidentius, primum ex ea caritate quae est inter natos et parentes, quae dirimi nisi detestabili scelere non potest; deinde cum similis sensus exstitit amoris, si aliquem nacti sumus cuius cum moribus et natura congruamus, quod in eo quasi lumen aliquod probitatis et virtutis perspicere videamur.\r\n\r\nCum saepe multa, tum memini domi in hemicyclio sedentem, ut solebat, cum et ego essem una et pauci admodum familiares, in eum sermonem illum incidere qui tum forte multis erat in ore. Meministi enim profecto, Attice, et eo magis, quod P. Sulpicio utebare multum, cum is tribunus plebis capitali odio a Q. Pompeio, qui tum erat consul, dissideret, quocum coniunctissime et amantissime vixerat, quanta esset hominum vel admiratio vel querella.','NBS Business School','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.','publish','closed','closed','','nbs-business-school','','','2026-02-26 20:16:14','2026-02-26 20:16:14','',0,'https://chloecrase.ddev.site/?post_type=project&#038;p=16',0,'project','',0),
(18,1,'2026-02-15 20:44:00','2026-02-15 20:44:00','','nbs-1','','inherit','open','closed','','nbs-1','','','2026-02-15 20:44:00','2026-02-15 20:44:00','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-1.png',0,'attachment','image/png',0),
(19,1,'2026-02-15 20:44:01','2026-02-15 20:44:01','','nbs-2','','inherit','open','closed','','nbs-2','','','2026-02-15 20:44:01','2026-02-15 20:44:01','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-2.png',0,'attachment','image/png',0),
(20,1,'2026-02-15 20:44:02','2026-02-15 20:44:02','','nbs-3','','inherit','open','closed','','nbs-3','','','2026-02-26 20:09:12','2026-02-26 20:09:12','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-3.png',0,'attachment','image/png',0),
(21,1,'2026-02-15 20:44:03','2026-02-15 20:44:03','','nbs-4','','inherit','open','closed','','nbs-4','','','2026-02-26 20:10:29','2026-02-26 20:10:29','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-4.png',0,'attachment','image/png',0),
(22,1,'2026-02-15 20:44:33','2026-02-15 20:44:33','','nbs-5','','inherit','open','closed','','nbs-5','','','2026-02-15 20:44:33','2026-02-15 20:44:33','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-5.png',0,'attachment','image/png',0),
(23,1,'2026-02-15 20:44:39','2026-02-15 20:44:39','','nbs-6','','inherit','open','closed','','nbs-6','','','2026-02-26 19:53:20','2026-02-26 19:53:20','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-6.png',0,'attachment','image/png',0),
(24,1,'2026-02-15 20:44:43','2026-02-15 20:44:43','','nbs-7','','inherit','open','closed','','nbs-7','','','2026-02-26 19:53:36','2026-02-26 19:53:36','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-7.png',0,'attachment','image/png',0),
(25,1,'2026-02-15 20:45:13','2026-02-15 20:45:13','','nbs-8','','inherit','open','closed','','nbs-8','','','2026-02-15 20:45:13','2026-02-15 20:45:13','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-8.png',0,'attachment','image/png',0),
(26,1,'2026-02-15 20:45:16','2026-02-15 20:45:16','','nbs-9','','inherit','open','closed','','nbs-9','','','2026-02-15 20:45:16','2026-02-15 20:45:16','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-9.png',0,'attachment','image/png',0),
(27,1,'2026-02-15 20:45:18','2026-02-15 20:45:18','','nbs-10','','inherit','open','closed','','nbs-10','','','2026-02-26 19:53:46','2026-02-26 19:53:46','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-10.png',0,'attachment','image/png',0),
(28,1,'2026-02-15 20:45:22','2026-02-15 20:45:22','','nbs-11','','inherit','open','closed','','nbs-11','','','2026-02-15 20:45:22','2026-02-15 20:45:22','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-11.png',0,'attachment','image/png',0),
(29,1,'2026-02-15 20:45:26','2026-02-15 20:45:26','','nbs-12','','inherit','open','closed','','nbs-12','','','2026-02-26 19:54:01','2026-02-26 19:54:01','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-12.png',0,'attachment','image/png',0),
(30,1,'2026-02-15 20:45:27','2026-02-15 20:45:27','','nbs-13','','inherit','open','closed','','nbs-13','','','2026-02-15 20:45:27','2026-02-15 20:45:27','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-13.png',0,'attachment','image/png',0),
(31,1,'2026-02-15 20:45:31','2026-02-15 20:45:31','','nbs-14','','inherit','open','closed','','nbs-14','','','2026-02-15 20:45:31','2026-02-15 20:45:31','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-14.png',0,'attachment','image/png',0),
(32,1,'2026-02-15 20:45:39','2026-02-15 20:45:39','','nbs-15','','inherit','open','closed','','nbs-15','','','2026-02-26 19:54:14','2026-02-26 19:54:14','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-15.png',0,'attachment','image/png',0),
(33,1,'2026-02-15 20:45:47','2026-02-15 20:45:47','','nbs-16','','inherit','open','closed','','nbs-16','','','2026-02-26 19:54:26','2026-02-26 19:54:26','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-16.png',0,'attachment','image/png',0),
(34,1,'2026-02-15 20:45:52','2026-02-15 20:45:52','','nbs-17','','inherit','open','closed','','nbs-17','','','2026-02-15 20:45:52','2026-02-15 20:45:52','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-17.png',0,'attachment','image/png',0),
(35,1,'2026-02-15 20:45:56','2026-02-15 20:45:56','','nbs-18','','inherit','open','closed','','nbs-18','','','2026-02-26 19:54:40','2026-02-26 19:54:40','',16,'https://chloecrase.ddev.site/app/uploads/2026/02/nbs-18.png',0,'attachment','image/png',0),
(36,1,'2026-02-21 14:35:23','2026-02-21 14:35:23','','thumb-nbs','','inherit','open','closed','','thumb-nbs','','','2026-02-21 14:35:23','2026-02-21 14:35:23','',0,'https://chloecrase.ddev.site/app/uploads/2026/02/thumb-nbs.png',0,'attachment','image/png',0),
(37,1,'2026-02-21 15:05:14','2026-02-21 15:05:14','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-21 15:05:14','2026-02-21 15:05:14','',5,'https://chloecrase.ddev.site/?p=37',0,'revision','',0),
(38,1,'2026-02-21 16:50:56','2026-02-21 16:50:56','','Processed with VSCO with 2 preset','Processed with VSCO with 2 preset','inherit','open','closed','','processed-with-vsco-with-2-preset','','','2026-02-26 20:08:45','2026-02-26 20:08:45','',5,'https://chloecrase.ddev.site/app/uploads/2026/02/chloe-1.jpg',0,'attachment','image/jpeg',0),
(39,1,'2026-02-21 16:51:04','2026-02-21 16:51:04','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-21 16:51:04','2026-02-21 16:51:04','',5,'https://chloecrase.ddev.site/?p=39',0,'revision','',0),
(40,1,'2026-02-22 15:19:34','2026-02-22 15:19:34','','De Saint-Gall','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.','publish','closed','closed','','de-saint-gall','','','2026-02-24 12:58:43','2026-02-24 12:58:43','',0,'https://chloecrase.ddev.site/?post_type=project&#038;p=40',0,'project','',0),
(41,1,'2026-02-22 15:20:40','2026-02-22 15:20:40','','thumb-de-saint-gall','','inherit','open','closed','','thumb-de-saint-gall','','','2026-02-22 15:20:40','2026-02-22 15:20:40','',40,'https://chloecrase.ddev.site/app/uploads/2026/02/thumb-de-saint-gall.png',0,'attachment','image/png',0),
(43,1,'2026-02-22 15:37:53','2026-02-22 15:37:53','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-22 15:37:53','2026-02-22 15:37:53','',5,'https://chloecrase.ddev.site/?p=43',0,'revision','',0),
(44,1,'2026-02-24 12:23:31','2026-02-24 12:23:31','','Mamie Boulangerie','Je cherche du sens, une émotion juste, une image qui reste.\r\nEt quand un projet s’engage, je m’engage aussi, pour déplacer les regards, à mon échelle.','publish','closed','closed','','mamie-boulangerie','','','2026-02-24 12:36:00','2026-02-24 12:36:00','',0,'https://chloecrase.ddev.site/?post_type=project&#038;p=44',0,'project','',0),
(45,1,'2026-02-24 12:24:01','2026-02-24 12:24:01','','thumb-mamie-boulangerie','','inherit','open','closed','','thumb-mamie-boulangerie','','','2026-02-24 12:24:01','2026-02-24 12:24:01','',44,'https://chloecrase.ddev.site/app/uploads/2026/02/thumb-mamie-boulangerie.jpg',0,'attachment','image/jpeg',0),
(46,1,'2026-02-24 22:06:21','2026-02-24 22:06:21','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-24 22:06:21','2026-02-24 22:06:21','',5,'https://chloecrase.ddev.site/?p=46',0,'revision','',0),
(47,1,'2026-02-24 22:06:42','2026-02-24 22:06:42','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-24 22:06:42','2026-02-24 22:06:42','',5,'https://chloecrase.ddev.site/?p=47',0,'revision','',0),
(48,1,'2026-02-24 22:27:45','2026-02-24 22:27:45','','image-begin','','inherit','open','closed','','image-begin','','','2026-02-26 20:10:02','2026-02-26 20:10:02','',5,'https://chloecrase.ddev.site/app/uploads/2026/02/image-begin.jpg',0,'attachment','image/jpeg',0),
(49,1,'2026-02-24 22:28:16','2026-02-24 22:28:16','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-24 22:28:16','2026-02-24 22:28:16','',5,'https://chloecrase.ddev.site/?p=49',0,'revision','',0),
(50,1,'2026-02-25 19:57:50','2026-02-25 19:57:50','','chloe-2','','inherit','open','closed','','chloe-2','','','2026-02-26 20:09:02','2026-02-26 20:09:02','',5,'https://chloecrase.ddev.site/app/uploads/2026/02/chloe-2.jpg',0,'attachment','image/jpeg',0),
(51,1,'2026-02-25 19:59:08','2026-02-25 19:59:08','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 19:59:08','2026-02-25 19:59:08','',5,'https://chloecrase.ddev.site/?p=51',0,'revision','',0),
(52,1,'2026-02-25 19:59:16','2026-02-25 19:59:16','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 19:59:16','2026-02-25 19:59:16','',5,'https://chloecrase.ddev.site/?p=52',0,'revision','',0),
(53,1,'2026-02-25 19:59:39','2026-02-25 19:59:39','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 19:59:39','2026-02-25 19:59:39','',5,'https://chloecrase.ddev.site/?p=53',0,'revision','',0),
(54,1,'2026-02-25 20:21:46','2026-02-25 20:21:46','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 20:21:46','2026-02-25 20:21:46','',5,'https://chloecrase.ddev.site/?p=54',0,'revision','',0),
(55,1,'2026-02-25 20:26:20','2026-02-25 20:26:20','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 20:26:20','2026-02-25 20:26:20','',5,'https://chloecrase.ddev.site/?p=55',0,'revision','',0),
(56,1,'2026-02-25 22:05:11','2026-02-25 22:05:11','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 22:05:11','2026-02-25 22:05:11','',5,'https://chloecrase.ddev.site/?p=56',0,'revision','',0),
(57,1,'2026-02-25 22:08:17','2026-02-25 22:08:17','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 22:08:17','2026-02-25 22:08:17','',5,'https://chloecrase.ddev.site/?p=57',0,'revision','',0),
(58,1,'2026-02-25 22:26:16','2026-02-25 22:26:16','','Accueil','','inherit','closed','closed','','5-revision-v1','','','2026-02-25 22:26:16','2026-02-25 22:26:16','',5,'https://chloecrase.ddev.site/?p=58',0,'revision','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES
(1,1,0),
(6,2,0),
(10,3,0),
(11,3,0),
(16,4,0),
(16,5,0),
(40,4,0),
(40,5,0),
(40,7,0),
(44,4,0),
(44,8,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES
(1,1,'category','',0,1),
(2,2,'wp_theme','',0,1),
(3,3,'nav_menu','',0,2),
(4,4,'project_category','',0,3),
(5,5,'project_category','',0,2),
(6,6,'project_category','',0,0),
(7,7,'project_category','',0,1),
(8,8,'project_category','',0,1);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES
(1,'Uncategorized','uncategorized',0),
(2,'sage','sage',0),
(3,'menu-main','menu-main',0),
(4,'Direction artistique','direction-artistique',0),
(5,'Rebranding','rebranding',0),
(6,'Social Media','social-media',0),
(7,'Shooting Photo','shooting-photo',0),
(8,'Stratégie de marque','strategie-de-marque',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES
(1,1,'nickname','developper'),
(2,1,'first_name',''),
(3,1,'last_name',''),
(4,1,'description',''),
(5,1,'rich_editing','true'),
(6,1,'syntax_highlighting','true'),
(7,1,'comment_shortcuts','false'),
(8,1,'admin_color','fresh'),
(9,1,'use_ssl','0'),
(10,1,'show_admin_bar_front','false'),
(11,1,'locale',''),
(12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
(13,1,'wp_user_level','10'),
(14,1,'dismissed_wp_pointers',''),
(15,1,'show_welcome_panel','0'),
(16,1,'session_tokens','a:1:{s:64:\"07e14caaacc3c14be88558243a3d43d6066ce3c77631a005992abd7f5202cdfb\";a:4:{s:10:\"expiration\";i:1772143520;s:2:\"ip\";s:12:\"192.168.97.5\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36\";s:5:\"login\";i:1771970720;}}'),
(17,1,'wp_dashboard_quick_press_last_post_id','4'),
(18,1,'community-events-location','a:1:{s:2:\"ip\";s:12:\"192.168.97.0\";}'),
(19,1,'wp_persisted_preferences','a:3:{s:4:\"core\";a:1:{s:26:\"isComplementaryAreaVisible\";b:1;}s:14:\"core/edit-post\";a:1:{s:12:\"welcomeGuide\";b:0;}s:9:\"_modified\";s:24:\"2026-02-15T17:52:32.502Z\";}'),
(20,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21,1,'metaboxhidden_nav-menus','a:1:{i:0;s:12:\"add-post_tag\";}'),
(22,1,'closedpostboxes_page','a:0:{}'),
(23,1,'metaboxhidden_page','a:5:{i:0;s:12:\"revisionsdiv\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}'),
(24,1,'wp_user-settings','libraryContent=browse&editor=tinymce'),
(25,1,'wp_user-settings-time','1772135360'),
(26,1,'manageedit-acf-taxonomycolumnshidden','a:1:{i:0;s:7:\"acf-key\";}'),
(27,1,'acf_user_settings','a:2:{s:20:\"taxonomies-first-run\";b:1;s:23:\"options-pages-first-run\";b:1;}'),
(28,1,'manageedit-acf-ui-options-pagecolumnshidden','a:1:{i:0;s:7:\"acf-key\";}'),
(29,1,'nav_menu_recently_edited','3');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES
(1,'developper','$wp$2y$10$PVCqMVQ6Iy0MzXH32WDiaugoIafHtnSbSyIV1KRSJPd7hly/lW2mC','developper','othman.bensaoula@gmail.com','https://chloecrase.ddev.site/wp','2026-02-15 17:41:30','',0,'developper');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-26 21:55:55
